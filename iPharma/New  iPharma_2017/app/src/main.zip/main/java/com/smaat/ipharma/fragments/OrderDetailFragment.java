package com.smaat.ipharma.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.smaat.ipharma.R;
import com.smaat.ipharma.adapter.MapListAdapter;
import com.smaat.ipharma.apiinterface.APIRequestHandler;
import com.smaat.ipharma.entity.CommonResponse;
import com.smaat.ipharma.entity.MapPropertyEntity;
import com.smaat.ipharma.entity.NewOrderEntity;
import com.smaat.ipharma.main.BaseFragment;
import com.smaat.ipharma.ui.HomeScreen;
import com.smaat.ipharma.utils.AppConstants;
import com.smaat.ipharma.utils.DialogManager;
import com.smaat.ipharma.utils.GPSTracker;
import com.smaat.ipharma.utils.GlobalMethods;
import com.smaat.ipharma.utils.ProfileImageSelectionUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.smaat.ipharma.utils.AppConstants.Choosed_Image;
import static com.smaat.ipharma.utils.AppConstants.DELIVERY_STATUS;
import static com.smaat.ipharma.utils.AppConstants.FROMHISTORY;
import static com.smaat.ipharma.utils.AppConstants.FROM_MY_ORDER;

/**
 * Created by admin on 1/24/2017.
 */

public class OrderDetailFragment extends BaseFragment {

    @BindView(R.id.shop_image)
    ImageView m_shopimage;

    @BindView(R.id.shop_name)
    TextView m_shopName;

    @BindView(R.id.shop_address)
    TextView m_shopAddress;

    @BindView(R.id.del_address)
    TextView m_del_addr;

    @BindView(R.id.note)
    TextView m_note_addr;


    MapPropertyEntity mpentity;

    private String UserID = "";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.ui_order_detail,
                container, false);
        ButterKnife.bind(this, rootview);
        setupUI(rootview);
        UserID = GlobalMethods.getUserID(getActivity());
        mpentity = AppConstants.PharmacyDetails;
        initcomponents();
        return rootview;
    }


    private void initcomponents() {
        mpentity =AppConstants.PharmacyDetails;
        if(FROMHISTORY)
        {
            Log.e("Choosed_Ima","Choosed_ImageChoosed_Image"+AppConstants.BASE_URL2 + "/"+ Choosed_Image);
            Glide.with(this).load(AppConstants.BASE_URL2 + "/"
                    +
                    Choosed_Image)
                    .thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(m_shopimage);
        }else{
            m_shopimage.setImageBitmap(HomeScreen.mSelectedImgBitmap);
        }

        m_shopName.setText(mpentity.getShopName());
        m_shopAddress.setText(mpentity.getAddress());
        m_del_addr.setText(GlobalMethods.getStringValue(getActivity(),AppConstants.COMMUNICATION_ADDRESS));
        m_shopimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* Intent i = new Intent(getActivity(),ViewShopMapFragment.class);
                i.putExtra("ShowImage",true);
                startActivity(i);*/
            }
        });
    }

    public void LoadPlaceorder()
    {
        APIRequestHandler.getInstance().Placeorder(mpentity.getPharmacyID(), UserID,
                m_del_addr.getText().toString(), m_shopAddress.getText().toString(), m_note_addr.getText().toString(),
                OrderDetailFragment.this);

    }

    @Override
    public void onResume() {
        super.onResume();
        if(FROM_MY_ORDER)
        {
           ((HomeScreen) getActivity()).setToolbarTitle(getString(R.string.or_det),AppConstants.DELIVERY_STATUS);
        }else{
           ((HomeScreen) getActivity()).setToolbarTitle(getString(R.string.or_det),getString(R.string.plce_order));
        }




    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        super.onRequestSuccess(responseObj);
        NewOrderEntity resultObj = (NewOrderEntity) responseObj;
        if(resultObj.getMsg().equalsIgnoreCase(AppConstants.SUCCESS))
        {
            DialogManager.showSucessPopup(getActivity(), getString(R.string.app_name), getString(R.string.order_dialog_text));
        }
    }

}
