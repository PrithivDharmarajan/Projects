package com.smaat.ipharma.utils;

import android.graphics.Bitmap;

public interface ImageCallback {

	void imageDetails(Bitmap data);
}
