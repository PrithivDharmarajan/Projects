package com.smaat.ipharma.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.smaat.ipharma.R;
import com.smaat.ipharma.main.BaseFragment;
import com.smaat.ipharma.ui.HomeScreen;
import com.smaat.ipharma.utils.AppConstants;
import com.smaat.ipharma.utils.DialogManager;
import com.smaat.ipharma.utils.GlobalMethods;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by admin on 2/9/2017.
 */

public class ReminderSettings  extends BaseFragment {


    @BindView(R.id.doctor_number)
    TextView doctor_number;

    @BindView(R.id.guardian_number)
    TextView guardian_number;

    @BindView(R.id.save_btn)
    Button save_btn;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View m_pill_reminderRootView = inflater.inflate(R.layout.ui_reminder_settings, container, false);
        ButterKnife.bind(this, m_pill_reminderRootView);
        setupUI(m_pill_reminderRootView);
        doctor_number.setText(GlobalMethods.getStringValue(getActivity(), AppConstants.GUARDIAN_NUMBER));
        guardian_number.setText(GlobalMethods.getStringValue(getActivity(), AppConstants.DOCTOR_NUMBER));
        save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(guardian_number.getText().toString().trim().isEmpty()
                        &&doctor_number.getText().toString().trim().isEmpty())
                {
                    DialogManager.showMsgPopup(getActivity(),"","Please Enter a Valid Mobile Number");
                }else{
                        if(!guardian_number.getText().toString().equalsIgnoreCase(""))
                        {
                            GlobalMethods.storeValuetoPreference(getActivity(),GlobalMethods.STRING_PREFERENCE, AppConstants.GUARDIAN_NUMBER,guardian_number.getText().toString());
                        }
                        if(!doctor_number.getText().toString().equalsIgnoreCase(""))
                        {
                            GlobalMethods.storeValuetoPreference(getActivity(),GlobalMethods.STRING_PREFERENCE, AppConstants.DOCTOR_NUMBER,doctor_number.getText().toString());
                        }
                        DialogManager.showMsgPopup(getActivity(),"",getString(R.string.set_sav_suc));
                }

                /*if(guardian_number.getText().toString().trim().isEmpty()
                        && guardian_number.getText().toString().trim().length() < 1
                        && guardian_number.getText().toString().trim().equalsIgnoreCase(""))
                {
                    DialogManager.showMsgPopup(getActivity(),"","Enter a Guardian Number");

                }else if(doctor_number.getText().toString().trim().isEmpty()
                        && doctor_number.getText().toString().trim().length() < 1
                        && doctor_number.getText().toString().trim().equalsIgnoreCase(""))
                {
                    DialogManager.showMsgPopup(getActivity(),"","Enter a Doctor Number");

                }else{
                    GlobalMethods.storeValuetoPreference(getActivity(),GlobalMethods.STRING_PREFERENCE, AppConstants.GUARDIAN_NUMBER,guardian_number.getText().toString());
                    GlobalMethods.storeValuetoPreference(getActivity(),GlobalMethods.STRING_PREFERENCE, AppConstants.DOCTOR_NUMBER,doctor_number.getText().toString());
                    DialogManager.showMsgPopup(getActivity(),"",getString(R.string.set_sav_suc));
                }*/




            }
        });

        return m_pill_reminderRootView;

    }

    @Override
    public void onResume() {
        super.onResume();
        ((HomeScreen) getActivity()).setToolbarTitle(getString(R.string.reminder_st),getString(R.string.home));
    }
}
