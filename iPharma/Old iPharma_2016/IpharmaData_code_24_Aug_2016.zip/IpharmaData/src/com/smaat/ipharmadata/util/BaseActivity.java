package com.smaat.ipharmadata.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.androidquery.AQuery;
import com.smaat.ipharmadata.R;
import com.smaat.ipharmadata.database.DatabaseHelper;
import com.smaat.ipharmadata.database.DatabaseManager;

public class BaseActivity extends Activity {

	private static AlertDialog alertDialog;
	private static Activity _activity;
	public static Dialog mDialog;
	private AQuery aq;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		_activity = this;
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
						| WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		DatabaseManager.initialize(getApplicationContext(), new DatabaseHelper(
				this));
		this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

	}

	@SuppressWarnings("deprecation")
	public static void showAlert(final Activity activity) {
		alertDialog = new AlertDialog.Builder(activity).create();
		alertDialog.setTitle("No Internet Connection");
		alertDialog.setMessage("You don't have internet connection.");
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
		alertDialog.show();

	}
	
	protected void onLatLongUpdate(){
		
	}

	protected AQuery aq() {
		if (aq == null) {
			aq = new AQuery(_activity);
		}
		return aq;
	}

	public void setupUI(View view) {

		// Set up touch listener for non-text box views to hide keyboard.
		if (!(view instanceof EditText)) {

			view.setOnTouchListener(new OnTouchListener() {

				public boolean onTouch(View v, MotionEvent event) {
					hideSoftKeyboard(BaseActivity.this);
					return false;
				}

			});
		}

		// If a layout container, iterate over children and seed recursion.
		if (view instanceof ViewGroup) {

			for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {

				View innerView = ((ViewGroup) view).getChildAt(i);

				setupUI(innerView);
			}
		}
	}

	public void hideSoftKeyboard(Activity activity) {
		try {
			if (activity != null && !activity.isFinishing()) {
				InputMethodManager inputMethodManager = (InputMethodManager) activity
						.getSystemService(Activity.INPUT_METHOD_SERVICE);

				if (activity.getCurrentFocus() != null
						&& activity.getCurrentFocus().getWindowToken() != null) {
					inputMethodManager.hideSoftInputFromWindow(activity
							.getCurrentFocus().getWindowToken(), 0);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void setFont(ViewGroup group, Typeface font) {
		int count = group.getChildCount();
		View v;
		for (int i = 0; i < count; i++) {
			v = group.getChildAt(i);
			if (v instanceof TextView || v instanceof Button /* etc. */)
				((TextView) v).setTypeface(font);
			else if (v instanceof ViewGroup)
				setFont((ViewGroup) v, font);
		}
	}

	public void launchActivity(Class<?> clazz) {
		Intent intent = new Intent(_activity, clazz);

		_activity.startActivity(intent);

		// _activity.overridePendingTransition(R.anim.slide_in_right,
		// R.anim.slide_out_left);
		_activity.finish();
	}

	@Override
	protected void onPause() {
		if (alertDialog != null && alertDialog.isShowing()) {
			alertDialog.dismiss();
		}
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		if (alertDialog != null && alertDialog.isShowing()) {
			alertDialog.dismiss();
		}
		super.onDestroy();
	}

	public void onRequestSuccess(Object responseObj) {

	}

	public void onRequestFailure(String errorCode) {

		if (errorCode == null) {
			DialogManager.showPopUpDialog(this,
					(DialogMangerCallback) BaseActivity.this,
					getString(R.string.data_issue));
		} else if (errorCode.equals("-101")) {
			DialogManager.showPopUpDialog(this,
					(DialogMangerCallback) BaseActivity.this,
					getString(R.string.no_network));
		} else {
			DialogManager.showPopUpDialog(this,
					(DialogMangerCallback) BaseActivity.this,
					getString(R.string.server_unreachable));
		}
	}

}