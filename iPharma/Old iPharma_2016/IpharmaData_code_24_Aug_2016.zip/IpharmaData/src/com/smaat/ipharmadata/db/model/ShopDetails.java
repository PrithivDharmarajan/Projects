package com.smaat.ipharmadata.db.model;

import java.io.Serializable;

public class ShopDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private double latitude;
	private double longitude;
	private ShopImage image;
	private String username;
	private String phonenum;
	private int rowid;

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public ShopImage getImage() {
		return image;
	}

	public void setImage(ShopImage image) {
		this.image = image;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPhonenum() {
		return phonenum;
	}

	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}

	public int getRowid() {
		return rowid;
	}

	public void setRowid(int rowid) {
		this.rowid = rowid;
	}

}
