package com.smaat.ipharmadata.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.smaat.ipharmadata.R;
import com.smaat.ipharmadata.util.AppConstants;
import com.smaat.ipharmadata.util.GlobalMethods;

public class SplashScreen extends Activity {

	private String mIsFirst;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.spalsh);
		mIsFirst = (String) GlobalMethods.getValueFromPreference(this,
				GlobalMethods.STRING_PREFERENCE, AppConstants.IS_FIRST);
		if (mIsFirst.equalsIgnoreCase("0")) {
			mIsFirst = "IS_FIRST";
		}
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {

				if (mIsFirst.equalsIgnoreCase("")
						|| mIsFirst.equalsIgnoreCase("IS_FIRST")) {
					Intent intent = new Intent(SplashScreen.this,
							LoginScreen.class);
					startActivity(intent);
					finish();
				} else {
					Intent intent = new Intent(SplashScreen.this,
							DetailsActivity.class);
					startActivity(intent);
					finish();
				}
			}
		}, 500);
	}

}
