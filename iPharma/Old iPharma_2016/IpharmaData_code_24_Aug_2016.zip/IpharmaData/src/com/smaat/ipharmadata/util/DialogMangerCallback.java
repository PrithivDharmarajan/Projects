package com.smaat.ipharmadata.util;

public interface DialogMangerCallback {

	void onItemclick(String SelctedItem, int pos);

	void onOkclick();
	
	void onCancelclick();

}
