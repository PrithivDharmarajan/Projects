package com.smaat.ipharmadata.util;

import android.content.Context;
import android.graphics.Typeface;

public class TypefaceSingleton {

	private static final TypefaceSingleton instance = new TypefaceSingleton();
	private static Typeface helvetica;

	private TypefaceSingleton() {
	}

	public static TypefaceSingleton getInstance() {
		return instance;
	}

	public Typeface getHelvetica(Context context) {
		if (helvetica == null) {
			helvetica = Typeface.createFromAsset(context.getAssets(),
					"font/HelveticaNeue.ttf");

		}
		return helvetica;
	}

}
