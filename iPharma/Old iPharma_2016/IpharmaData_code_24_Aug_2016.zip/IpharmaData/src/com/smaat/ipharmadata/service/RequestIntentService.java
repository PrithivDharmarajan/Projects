package com.smaat.ipharmadata.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.androidquery.callback.AjaxStatus;
import com.androidquery.callback.Transformer;
import com.google.gson.Gson;
import com.parse.codec.binary.Base64;
import com.smaat.ipharmadata.db.model.UserDetails;

public class RequestIntentService extends IntentService {
	private static String profile;
	Context mContext;
	Intent intent;
	Bundle bundle;
	Handler mMainThreadHandler = null;
	StringBuilder responseString;
	Thread thread;

	public RequestIntentService(String name) {
		super(name);
		mMainThreadHandler = new Handler();

		thread = new Thread(new Runnable() {
			@Override
			public void run() {
			}
		});
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		// TODO Auto-generated method stub
		mContext = RequestIntentService.this;
		this.intent = intent;

		thread.start();
	}

	public static class GsonTransformer implements Transformer {

		public <T> T transform(String url, Class<T> type, String encoding,
				byte[] data, AjaxStatus status) {
			Gson g = new Gson();
			return g.fromJson(new String(data), type);
		}
	}

	public static CommonResponse saveProfile(UserDetails response) {

		String url = "http://smaatapps.com/iPharma/ipharmadetails";

		HttpPost httpPost = null;
		try {
			// httpPost = new HttpPost(url);
			// HttpClient httpclient = new DefaultHttpClient();
			// InputStream inputStream = null;
			//
			Gson gson = new Gson();
			String json1 = gson.toJson(response);
			//
			// StringEntity se = new StringEntity(json1);
			// System.out.println("pharma" + json1);
			// httpPost.setEntity(se);
			// httpPost.setHeader("Accept", "application/json");
			// httpPost.setHeader("Content-type", "application/json");
			// HttpResponse httpResponse = httpclient.execute(httpPost);
			// inputStream = httpResponse.getEntity().getContent();
			// String result = convertStreamToString(inputStream);
			// System.out.println(result);

			HttpResponse httpresponse = null;
			DefaultHttpClient httpclient = new DefaultHttpClient();
			HttpPost httppostreq = new HttpPost(url);

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			nameValuePairs.add(new BasicNameValuePair("userid", "1"));
			nameValuePairs.add(new BasicNameValuePair("phone1", response
					.getPhone1()));
			nameValuePairs.add(new BasicNameValuePair("phone2", response
					.getPhone1()));
			nameValuePairs.add(new BasicNameValuePair("phone3", response
					.getPhone1()));
			nameValuePairs.add(new BasicNameValuePair("phone4", response
					.getPhone1()));
			nameValuePairs.add(new BasicNameValuePair("pharmacy_name", response
					.getPharmacy_name()));
			nameValuePairs.add(new BasicNameValuePair("address", response
					.getAddress()));
			nameValuePairs.add(new BasicNameValuePair("owner_name", response
					.getOwner_name()));
			nameValuePairs.add(new BasicNameValuePair("website", response
					.getWebsite()));
			nameValuePairs.add(new BasicNameValuePair("email_id", response
					.getEmail_id()));
			nameValuePairs.add(new BasicNameValuePair("opening_time", response
					.getOpening_time()));
			nameValuePairs.add(new BasicNameValuePair("closing_time", response
					.getClosing_time()));
			nameValuePairs.add(new BasicNameValuePair("delivery_time", response
					.getDelivery_time()));
			nameValuePairs.add(new BasicNameValuePair("min_purchase", response
					.getMin_purchase()));
			nameValuePairs.add(new BasicNameValuePair("home_delivery", response
					.getHome_delivery()));
			nameValuePairs.add(new BasicNameValuePair("latitude", String
					.valueOf(response.getLatitude())));
			nameValuePairs.add(new BasicNameValuePair("longitude", String
					.valueOf(response.getLongitude())));
			nameValuePairs.add(new BasicNameValuePair("datetime", String
					.valueOf(response.getDatetime())));

			String base64String1 = Base64.encodeBase64String(response
					.getImage().getImage1());
			String base64String2 = Base64.encodeBase64String(response
					.getImage().getImage2());
			String base64String3 = Base64.encodeBase64String(response
					.getImage().getImage3());
			String base64String4 = Base64.encodeBase64String(response
					.getImage().getImage4());
			nameValuePairs.add(new BasicNameValuePair("image1", base64String1));
			nameValuePairs.add(new BasicNameValuePair("image2", base64String2));
			nameValuePairs.add(new BasicNameValuePair("image3", base64String3));
			nameValuePairs.add(new BasicNameValuePair("image4", base64String4));
			httppostreq.setEntity(new UrlEncodedFormEntity(nameValuePairs,
					"UTF-8"));

			httpresponse = httpclient.execute(httppostreq);

			profile = EntityUtils.toString(httpresponse.getEntity());
			System.out.println("Profile:::" + profile.toString());
			CommonResponse com = new Gson().fromJson(profile.toString(),
					CommonResponse.class);

			return com;

		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static String convertStreamToString(InputStream is) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));

		StringBuilder sb = new StringBuilder();

		String line = null;

		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return sb.toString();
	}

}
