package com.smaat.ipharmadata.util;

public interface OptionDialogInterfaceListener {
	public void okClick();

	public void cancelClick();
}
