package com.smaat.ipharmadata.db.model;

import java.io.Serializable;

public class UserDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private String phone_number;
	private String phone1;
	private String phone2;
	private String phone3;
	private String phone4;
	private String pharmacy_name;
	private String address;
	private String owner_name;
	private String website;
	private String email_id;
	private String opening_time;
	private String closing_time;
	private String delivery_time;
	private String min_purchase;
	private String home_delivery;

	private double latitude;
	private double longitude;
	private String datetime;
	private Image image;
	private String isDelivery;
	private int rowid;
	private int isNew;
	private String landmark;

	private String Breakstarttime;
	private String Device;
	private String Breakendtime;
	private String state;
	private String pincode;
	private String area;
	private String deliverycharge;
	private String refno;

	public String getBreakstarttime() {
		return Breakstarttime;
	}

	public void setBreakstarttime(String breakstarttime) {
		Breakstarttime = breakstarttime;
	}

	public String getDevice() {
		return Device;
	}

	public void setDevice(String device) {
		Device = device;
	}

	public String getBreakendtime() {
		return Breakendtime;
	}

	public void setBreakendtime(String breakendtime) {
		Breakendtime = breakendtime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getDeliverycharge() {
		return deliverycharge;
	}

	public void setDeliverycharge(String deliverycharge) {
		this.deliverycharge = deliverycharge;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPharmacy_name() {
		return pharmacy_name;
	}

	public void setPharmacy_name(String pharmacy_name) {
		this.pharmacy_name = pharmacy_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOwner_name() {
		return owner_name;
	}

	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getOpening_time() {
		return opening_time;
	}

	public void setOpening_time(String opening_time) {
		this.opening_time = opening_time;
	}

	public String getClosing_time() {
		return closing_time;
	}

	public void setClosing_time(String closing_time) {
		this.closing_time = closing_time;
	}

	public String getDelivery_time() {
		return delivery_time;
	}

	public void setDelivery_time(String delivery_time) {
		this.delivery_time = delivery_time;
	}

	public String getMin_purchase() {
		return min_purchase;
	}

	public void setMin_purchase(String min_purchase) {
		this.min_purchase = min_purchase;
	}

	public String getHome_delivery() {
		return home_delivery;
	}

	public void setHome_delivery(String home_delivery) {
		this.home_delivery = home_delivery;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public String getIsDelivery() {
		return isDelivery;
	}

	public void setIsDelivery(String isDelivery) {
		this.isDelivery = isDelivery;
	}

	public int getRowid() {
		return rowid;
	}

	public void setRowid(int rowid) {
		this.rowid = rowid;
	}

	public int getIsNew() {
		return isNew;
	}

	public void setIsNew(int isNew) {
		this.isNew = isNew;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}

	public String getPhone3() {
		return phone3;
	}

	public void setPhone3(String phone3) {
		this.phone3 = phone3;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getRefno() {
		return refno;
	}

	public void setRefno(String refno) {
		this.refno = refno;
	}

	public String getPhone4() {
		return phone4;
	}

	public void setPhone4(String phone4) {
		this.phone4 = phone4;
	}

}
