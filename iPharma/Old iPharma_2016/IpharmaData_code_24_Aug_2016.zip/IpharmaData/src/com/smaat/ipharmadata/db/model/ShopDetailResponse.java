package com.smaat.ipharmadata.db.model;

import java.util.ArrayList;

public class ShopDetailResponse {

	ArrayList<ShopDetails> pharma;

	public ArrayList<ShopDetails> getPharma() {
		return pharma;
	}

	public void setPharma(ArrayList<ShopDetails> pharma) {
		this.pharma = pharma;
	}

}
