/*package com.smaat.ipharmadata.activity;

import java.util.Random;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.smaat.ipharmadata.R;
import com.smaat.ipharmadata.util.BaseActivity;
import com.smaat.ipharmadata.util.GPSTracker;

public class MapActivity extends BaseActivity {

	public static double touchlongtitude, curLat, curLong;
	ProgressDialog progress;
	protected LocationManager locationManager;
	protected LocationListener locationListener;
	private GoogleMap mGoogleMap;
	private double mCurrentLatitude;
	private double mCurrentLongitude;
	Button save, cancel;
//	public static String pharmacyname, ownername, address, lat, longi,
//			landmark, website, email, phone1, phone2, phone3, phone4, opentime,
//			closetime, isdelivery, deliverytime, minpur;
	public static double foundLongitude, foundLatitude;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dialog_map);

		cancel = (Button) findViewById(R.id.cancel_btn);
		save = (Button) findViewById(R.id.save);

		save.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// launchActivity(DetailsActivity.class);
				MapActivity.this.finish();
			}
		});
		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// launchActivity(DetailsActivity.class);
				MapActivity.this.finish();

			}
		});
		initializeMap();
	}

	@SuppressLint("NewApi")
	private void initializeMap() {
		if (mGoogleMap == null) {

			mGoogleMap = ((MapFragment) getFragmentManager().findFragmentById(
					R.id.map_view)).getMap();

			if (mGoogleMap == null) {
				Toast.makeText(MapActivity.this,
						"Sorry! unable to create maps", Toast.LENGTH_SHORT)
						.show();
			} else {
				mGoogleMap.setMyLocationEnabled(true);
				mGoogleMap.getUiSettings().setZoomControlsEnabled(false);
				mGoogleMap.getUiSettings().setCompassEnabled(true);
				mGoogleMap.getUiSettings().setMyLocationButtonEnabled(true);
				mGoogleMap.getUiSettings().setRotateGesturesEnabled(true);
				mGoogleMap.setOnMapClickListener(new OnMapClickListener() {
					public void onMapClick(LatLng point) {
						curLat = point.latitude;
						curLong = point.longitude;
						mGoogleMap.clear();
						MarkerOptions marker = new MarkerOptions().position(
								new LatLng(point.latitude, point.longitude))
								.title("New Marker");
						mGoogleMap.addMarker(marker);
					}
				});
				

				if (Build.VERSION.SDK_INT > 17) {
					getCurrentLocation("isFirst");

				} else {
					LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
					Criteria criteria = new Criteria();

					Location location = locationManager
							.getLastKnownLocation(locationManager
									.getBestProvider(criteria, false));
					if (location != null) {
						mGoogleMap.animateCamera(CameraUpdateFactory
								.newLatLngZoom(
										new LatLng(location.getLatitude(),
												location.getLongitude()), 13));

						// create marker
						MarkerOptions marker1 = new MarkerOptions()
								.position(new LatLng(location.getLatitude(),
										location.getLongitude()));

						// Changing marker icon
						// marker.icon(BitmapDescriptorFactory
						// .fromResource(R.drawable.current_location));

						// adding marker
						mGoogleMap.addMarker(marker1);
						System.out.println("Latitude :::"
								+ location.getLatitude() + "Longitude:::"
								+ location.getLongitude());
					}
				}

			}
		}

	}

	private void getCurrentLocation(String string) {
		GPSTracker tracker = new GPSTracker(this);
		if (tracker.canGetLocation() == false) {
			tracker.showSettingsAlert();
		} else {
			mCurrentLatitude = tracker.getLatitude();
			mCurrentLongitude = tracker.getLongitude();
		}

		if (string.equalsIgnoreCase("isFirst")) {
			LatLng currentLatLong = new LatLng(mCurrentLatitude,
					mCurrentLongitude);

			getLatLong(mCurrentLatitude, mCurrentLongitude);
		}

	}

	private void getLatLong(double latitude, double longitude) {
		for (int i = 0; i < 10; i++) {

			Random random = new Random();
			double radiusInDegrees = 15 / 111000f;

			double u = random.nextDouble();
			double v = random.nextDouble();
			double w = radiusInDegrees * Math.sqrt(u);
			double t = 20 * Math.PI * v;
			double x = w * Math.cos(t);
			double y = w * Math.sin(t);
			double new_x = x / Math.cos(latitude);
			double new_y = y / Math.cos(longitude);

			foundLongitude = new_x + longitude;
			foundLatitude = new_y + latitude;
			System.out.println("Longitude: " + foundLongitude + "  Latitude: "
					+ foundLatitude);

		}
		LatLng newLatLng1 = null;
		newLatLng1 = new LatLng(mCurrentLatitude, mCurrentLongitude);

		mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(newLatLng1));
		mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

		// create marker
		MarkerOptions marker = new MarkerOptions().position(new LatLng(
				mCurrentLatitude, mCurrentLongitude));

		// Changing marker icon
		// marker.icon(BitmapDescriptorFactory
		// .fromResource(R.drawable.current_location));

		// adding marker
		mGoogleMap.addMarker(marker);

	}

}
*/