package com.smaat.ipharmadata.db.model;

public class ShopImage {
	byte[] receiptimg;
	byte[] shopimage1;
	byte[] shopimage2;
	byte[] shopimage3;

	public byte[] getReceiptimg() {
		return receiptimg;
	}

	public void setReceiptimg(byte[] receiptimg) {
		this.receiptimg = receiptimg;
	}

	public byte[] getShopimage1() {
		return shopimage1;
	}

	public void setShopimage1(byte[] shopimage1) {
		this.shopimage1 = shopimage1;
	}

	public byte[] getShopimage2() {
		return shopimage2;
	}

	public void setShopimage2(byte[] shopimage2) {
		this.shopimage2 = shopimage2;
	}

	public byte[] getShopimage3() {
		return shopimage3;
	}

	public void setShopimage3(byte[] shopimage3) {
		this.shopimage3 = shopimage3;
	}

}
