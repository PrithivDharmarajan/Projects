package com.smaat.ipharmadata.util;

public class AppConstants {

	public final static String FIRST_PASS = "FIRST_PASS";
	public final static String SECOND_PASS = "SECOND_PASS";
	public final static String PASSWORD = "PASSWORD";

	public final static String shared_pref_name = "AppLockPreference";
	public static final String SUCCESS_CODE = "1";
	// Push notification data
	public static final String SENDER_ID = "921199002897";
	public final static String pref_deviceReg_Id = "DEVICE_ID";
	public final static String pref_device_reg_status = "ISREGISTERED";
	public final static String pref_device_id_changed = "ISDEVICEIDCHANGED";
	public final static String api_Key = "AIzaSyCR9Kh1dyOH_sb521VOT8bJVnyArTPSx_s";

	// Shared Preference keys
	public final static String pref_isLoggedIn = "pref_isLoggedIn";
	public final static String pref_isTutorailSeen = "pref_isTutorailSeen";
	public final static String pref_account_type = "pref_account_type";
	public final static String pref_email = "pref_email";
	public final static String pref_userId = "pref_userId";
	public final static String pref_selected_apps = "pref_selected_apps";
	public static int pref_main = 1;
	public final static String islock = "islock";
	public final static String pref_type = "pref_type";
	public final static String pref_selected_acc = "selected_acc";
	public final static String pref_user_name = "uesr_name";
	public final static String pref_owner = "owner_name";

	public final static String pref_packagename = "pref_packagename";
	public final static String pref_lock_block = "pref_lock_block";

	public final static String REFERENCE_NUMBER = "REFERENCE_NUMBER";
	public final static String USER_NAME = "USER_NAME";
	public final static String PHONE_NUMBER = "PHONE_NUMBER";
	public final static String IS_FIRST = "IS_FIRST";

	public final static String DEVICE_ID = "DEVICE_ID";

	public final static String pref_individual = "pref_individual";
	public final static String FACEBOOK = "facebook";
	public final static String GOOGLE = "google";
	public final static String EMAIL = "email";
	public final static String RENTER = "renter";
	public final static String BUYER = "buyer";
	public final static String SELLER = "seller";
	public final static String AGENT = "agent";
	public final static String BROKER = "broker";
	public static String marker_id = "markerid";
	public static String fromFavourite = "Favourite";
	public static String bread = "bread";

	public final static String Get_started = "false";
	public static String pref_db = "false";

	public final static String PLACES_API_BASE = "AIzaSyDYRBAC2vE1DzEfI7sOsI8uRToPvs0w2S8";
	public final static String LOGIN_API = "http://smaatapps.com/rb/index.php/login";
	public final static String REGISTER_API = "http://smaatapps.com/rb/index.php/registration";
	public final static String FORGOT_PASS_API = "http://smaatapps.com/rb/index.php/forgotpassword";
	public final static String PP_API = "http://smaatapps.com/rb/index.php/content/pp";
	public final static String TC_API = "http://smaatapps.com/rb/index.php/content/tc";
	public final static String ADD_FAVOURITE_API = "http://smaatapps.com/rb/index.php/addtofavorite";
	public final static String ADD_BOARDS_API = "http://smaatapps.com/rb/index.php/addtoboards";
	public final static String PROPERTY_API = "http://smaatapps.com/rb/index.php/property";
	public final static String PROPERTY_DETAIL_API = "http://smaatapps.com/rb/index.php/property/view";
	public final static String GET_FAVOURITE_API = "http://smaatapps.com/rb/index.php/addtofavorite/view";
	public final static String GET_BOARDS_API = "http://smaatapps.com/rb/index.php/postboards/view";
	public final static String IMAGE_BASE_URL = "http://smaatapps.com/rb/property/";

	public static String CALL_MAP = "false";
	public static String CUSTOM_DIALOG_SHOWN = "false";
	public static String categoryName = "category";
	public static String catName = "catname";
	public static String cost = "cost";
	public static String newitem = "newitem";
	public static int positin = 0;
	public static String rowcount = "0";

}
