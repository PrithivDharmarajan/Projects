package com.smaat.ipharmadata.activity;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import com.androidquery.callback.AjaxCallback;
import com.androidquery.callback.AjaxStatus;
import com.google.gson.Gson;
import com.smaat.ipharmadata.R;
import com.smaat.ipharmadata.database.DatabaseUtil;
import com.smaat.ipharmadata.db.model.ShopDetails;
import com.smaat.ipharmadata.service.CommonResponse;
import com.smaat.ipharmadata.service.RequestIntentService.GsonTransformer;
import com.smaat.ipharmadata.util.AppConstants;
import com.smaat.ipharmadata.util.BaseActivity;
import com.smaat.ipharmadata.util.DialogManager;
import com.smaat.ipharmadata.util.DialogMangerCallback;
import com.smaat.ipharmadata.util.GPSTracker;
import com.smaat.ipharmadata.util.GlobalMethods;
import com.smaat.ipharmadata.util.ProfileImageSelectionUtil;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class CapturePharmacyActivity extends BaseActivity {

	private ImageView mReceiptimage, mShopimage1, mShopimage2, mShopimage3;
	private TextView mLat, mLong;
	public static double foundLongitude, foundLatitude;
	private int selectedImageId;
	private Bitmap profileImage;
	byte[] mReceiptimgbyt, mShopbyt1, mShopbyt2, mShopbyt3;
	ArrayList<ShopDetails> mShopdetails;
	private ProgressDialog progress;

	private GPSTracker gps;
	private String mLatstr = "", mLongstr = "";
	DatabaseUtil db;
	private String mUsernameStr = "", mPhoneNo = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pharmacy_capture);

		
		db = new DatabaseUtil(this);

		gps = new GPSTracker(CapturePharmacyActivity.this);
		// check if GPS enabled
		if (gps.canGetLocation()) {
			foundLatitude = gps.getLatitude();
			foundLongitude = gps.getLongitude();

		} else {

			gps.showSettingsAlert();
		}

		initializeviews();
		mUsernameStr = (String) GlobalMethods.getValueFromPreference(
				CapturePharmacyActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.USER_NAME);
		mPhoneNo = (String) GlobalMethods.getValueFromPreference(
				CapturePharmacyActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.PHONE_NUMBER);

	}

	private void initializeviews() {
		mLat = (TextView) findViewById(R.id.latitude);
		mLong = (TextView) findViewById(R.id.longitude);
		mReceiptimage = (ImageView) findViewById(R.id.img_receipt);
		mShopimage1 = (ImageView) findViewById(R.id.shop_img1);
		mShopimage2 = (ImageView) findViewById(R.id.shop_img2);
		mShopimage3 = (ImageView) findViewById(R.id.shop_img3);

		if (foundLatitude != 0.00) {
			mLatstr = String.format("%.4f", foundLatitude);
			mLat.setText(mLatstr);
		} else {
			mLatstr = String.format("%.4f", DialogManager.curLat);
			mLat.setText(mLatstr);
		}
		if (foundLongitude != 0.00) {
			// mLong.setText(String.format("%.4f", curLong));
			mLongstr = String.format("%.4f", foundLongitude);

			mLong.setText(mLongstr);
		} else {
			mLongstr = String.format("%.4f", DialogManager.curLong);

			mLong.setText(mLongstr);
		}

	}

	private void showImage(int id) {
		selectedImageId = id;
		ProfileImageSelectionUtil.showOption(CapturePharmacyActivity.this);
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.back_arrow:
			Intent intent = new Intent(this, DetailsActivity.class);
			startActivity(intent);
			finish();

			break;
		case R.id.save:
			if (validateFields()) {
				showUserOption();
			}

			break;

		case R.id.img_receipt:
			showImage(id);
			break;
		case R.id.shop_img1:
			showImage(id);
			break;
		case R.id.shop_img2:
			showImage(id);
			break;
		case R.id.shop_img3:
			showImage(id);
			break;
		case R.id.locate:
			
			new DialogManager().showMap(this);
//			Intent inte = new Intent(CapturePharmacyActivity.this,
//					MapActivity.class);

//			startActivity(inte);
			break;
		}

	}

	private void showUserOption() {

		// show dialog for want to show local db or not

		DialogManager.showDialogOkCancel(this, getString(R.string.app_name),
				getString(R.string.want_to_strore_localdb), mCallback);

	}

	private boolean validateFields() {

		if (mReceiptimgbyt == null) {
			DialogManager.showDialog(this, "Please select receipt image",
					getString(R.string.ok), null, 0, 0);
			return false;

		} else if (mShopbyt1 == null && mShopbyt2 == null && mShopbyt3 == null) {
			DialogManager.showDialog(this, "Please select any one shop image",
					getString(R.string.ok), null, 0, 0);
			return false;

		}
		return true;

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == ProfileImageSelectionUtil.CAMERA
				|| requestCode == ProfileImageSelectionUtil.GALLERY) {
			try {

				if (resultCode == RESULT_OK) {

					if (requestCode == ProfileImageSelectionUtil.CAMERA
							|| requestCode == ProfileImageSelectionUtil.GALLERY) {

						Bitmap image = ProfileImageSelectionUtil.getImage(data,
								this);

						if (image != null) {
							if (requestCode == ProfileImageSelectionUtil.CAMERA) {
								if (ProfileImageSelectionUtil.isUriTrue) {
									image = ProfileImageSelectionUtil
											.getCorrectOrientationImage(this,
													data.getData(), image);
								} else {
									image = ProfileImageSelectionUtil
											.getCorrectOrientationImage(this,
													image);
								}
							} else {

								Uri selectedImage = data.getData();

								image = ProfileImageSelectionUtil
										.getCorrectOrientationImage(this,
												selectedImage, image);
							}
							ByteArrayOutputStream oututStream = new ByteArrayOutputStream();
							switch (selectedImageId) {
							case R.id.img_receipt:
								profileImage = image;
								aq().id(R.id.img_receipt).getImageView()
										.setImageBitmap(image);
								if (profileImage != null) {

									profileImage.compress(
											Bitmap.CompressFormat.PNG, 50,
											oututStream);
									mReceiptimgbyt = (oututStream)
											.toByteArray();

								}
								break;

							case R.id.shop_img1:
								profileImage = image;
								aq().id(R.id.shop_img1).getImageView()
										.setImageBitmap(image);
								if (profileImage != null) {

									profileImage.compress(
											Bitmap.CompressFormat.PNG, 50,
											oututStream);
									mShopbyt1 = (oututStream).toByteArray();

								}
								break;
							case R.id.shop_img2:
								profileImage = image;
								aq().id(R.id.shop_img2).getImageView()
										.setImageBitmap(image);
								if (profileImage != null) {

									profileImage.compress(
											Bitmap.CompressFormat.PNG, 50,
											oututStream);
									mShopbyt2 = (oututStream).toByteArray();

								}
								break;
							case R.id.shop_img3:
								profileImage = image;
								aq().id(R.id.shop_img3).getImageView()
										.setImageBitmap(image);
								if (profileImage != null) {

									profileImage.compress(
											Bitmap.CompressFormat.PNG, 50,
											oututStream);
									mShopbyt3 = (oututStream).toByteArray();

								}
								break;
							default:
								break;
							}
						} else {

							DialogManager.showDialog(this,
									"Image not available",
									getString(R.string.ok), null, 0, 0);
						}
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	// Dialog callback

	DialogMangerCallback mCallback = new DialogMangerCallback() {

		@Override
		public void onOkclick() {

			// progress = new ProgressDialog(CapturePharmacyActivity.this);
			//
			// if (progress != null) {
			// progress.setTitle(R.string.app_name);
			// progress.setMessage("Please be patient...");
			// progress.setCancelable(false);
			// progress.show();
			// }
			db.InsertShopdetails(CapturePharmacyActivity.this, mUsernameStr,
					mPhoneNo, Double.valueOf(mLatstr),
					Double.valueOf(mLongstr), mReceiptimgbyt, mShopbyt1,
					mShopbyt2, mShopbyt3, "0");
			mShopdetails = db.getShopprofile();

			DialogManager.showMessageDialogwithCallback(
					CapturePharmacyActivity.this,
					"Data has been saved locally.",
					mFinishcallback);

		}

		@Override
		public void onCancelclick() {
			callWebservice(mUsernameStr, mPhoneNo, CapturePharmacyActivity.this);

		}

		@Override
		public void onItemclick(String SelctedItem, int pos) {

		}
	};

	DialogMangerCallback mFinishcallback = new DialogMangerCallback() {

		@Override
		public void onOkclick() {

			Intent intent = new Intent(CapturePharmacyActivity.this,
					DetailsActivity.class);
			startActivity(intent);
			finish();

		}

		@Override
		public void onItemclick(String SelctedItem, int pos) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onCancelclick() {
			// TODO Auto-generated method stub

		}
	};

	@Override
	protected void onResume() {
		super.onResume();

		
	}

	private void callWebservice(String mUsernameStr, String mPhoneNo,
			final CapturePharmacyActivity capturePharmacyActivity) {
		DialogManager.showProgress(CapturePharmacyActivity.this);
		HashMap<String, Object> params = new HashMap<String, Object>();
		// final String url = "http://smaatapps.com/iPharma/ipharmadetails";
		final String url = "http://smaatapps.com/iPharma/index.php/TempParmacyCollection";

		params.put("userid", "1");
		params.put("username", mUsernameStr);
		params.put("mobile", mPhoneNo);
		params.put("latitude", mLatstr);
		params.put("longitude", mLongstr);
		params.put("receipt_image", mReceiptimgbyt);
		params.put("shop_image1", mShopbyt1);
		params.put("shop_image2", mShopbyt2);
		params.put("shop_image3", mShopbyt3);

		GsonTransformer t = new GsonTransformer();

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq().transformer(t).ajax(url, params, JSONObject.class,
				new AjaxCallback<JSONObject>() {
					public void callback(String url, JSONObject profile,
							AjaxStatus status) {

						if (profile != null) {

							try {
								if (progress != null) {
									progress.cancel();
								}
								CommonResponse obj = new Gson().fromJson(
										profile.toString(),
										CommonResponse.class);
								System.out.println("Profile:::"
										+ profile.toString());

								capturePharmacyActivity.onRequestCallBack(obj);
							} catch (Exception e) {
								e.printStackTrace();
								capturePharmacyActivity.onRequestCallBack(null);
							}

						} else {
							capturePharmacyActivity.onRequestCallBack(null);
						}

					}

				});

	}

	protected void onRequestCallBack(CommonResponse response) {
		DialogManager.hideProgress(CapturePharmacyActivity.this);
		if (response != null) {
			if (progress != null) {
				progress.cancel();
			}
			if (response.getError_code().equalsIgnoreCase("1")) {

				GlobalMethods.storeValuetoPreference(
						CapturePharmacyActivity.this,
						GlobalMethods.STRING_PREFERENCE, AppConstants.rowcount,
						response.getResult());
				DialogManager.showMessageDialogwithCallback(
						CapturePharmacyActivity.this,
						"Data has been successfully uploaded to server",
						mFinishcallback);

			}
		} else {
			DialogManager.showMessageDialog(CapturePharmacyActivity.this,
					"Failed to upload", "ok");
		}

	}
	
	@Override
	protected void onLatLongUpdate() {
		if (DialogManager.curLat != 0.00) {
			mLatstr = String.format("%.4f", DialogManager.curLat);
			mLat.setText(mLatstr);
		} else {
			mLatstr = String.format("%.4f", foundLatitude);
			mLat.setText(mLatstr);
		}
		if (DialogManager.curLong != 0.00) {
			// mLong.setText(String.format("%.4f", curLong));
			mLongstr = String.format("%.4f", DialogManager.curLong);

			mLong.setText(mLongstr);
		} else {
			mLongstr = String.format("%.4f", foundLongitude);

			mLong.setText(mLongstr);
		}
	}
}
