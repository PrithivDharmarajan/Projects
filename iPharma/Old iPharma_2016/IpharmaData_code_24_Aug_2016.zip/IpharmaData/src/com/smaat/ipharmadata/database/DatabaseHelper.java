package com.smaat.ipharmadata.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

	private static final int DATABASE_VERSION = 2;
	private static final String DATABASE_NAME = "appdetail.sqlite";

	public static final String TABLE_MYPROFILE = "myapp";

	public static final String KEY_OWNER = "owner_name";
	public static final String KEY_EMAIL = "email";
	public static final String KEY_PHARMA_NAME = "pharma_name";
	public static final String KEY_ADDRESS = "addresss";
	public static final String KEY_PHONE1 = "phone1";
	public static final String KEY_PHONE2 = "phone2";
	public static final String KEY_PHONE3 = "phone3";
	public static final String KEY_PHONE4 = "phone4";

	public static final String KEY_WEBSITE = "website";
	public static final String KEY_OPEN_TIME = "open_time";
	public static final String KEY_CLOSE_TIME = "close_time";
	public static final String KEY_DELIVER_TIME = "delivery_time";
	public static final String KEY_MIN_PURCHASE = "mini_pur";
	public static final String KEY_IS_NEW = "new_one";
	public static final String KEY_LAT = "lat";
	public static final String KEY_LONG = "long";
	public static final String KEY_PHOTO1 = "photo1";
	public static final String KEY_PHOTO2 = "photo2";
	public static final String KEY_PHOTO3 = "photo3";
	public static final String KEY_PHOTO4 = "photo4";
	public static final String KEY_DATE = "date";
	public static final String KEY_IS_DELIVERY = "isdelivery";
	public static final String KEY_USERID = "userid";
	public static final String KEY_ROW_ID = "rowid";
	public static final String KEY_LAND = "land";
	public static final String KEY_BREAKSTART = "Breakstarttime";
	public static final String KEY_BREAKEND = "Breakendtime";
	public static final String KEY_PINCODE = "pincode";
	public static final String KEY_STATE = "state";
	public static final String KEY_AREA = "area";
	public static final String KEY_DELIVERYCGE = "deliverycharge";

	// Capture Pharmacy DB

	public static final String TABLE_CAPTUREPHARMACY = "capturepharmacy";

	public static final String KEY_SHOPROW_ID = "shoprowid";
	public static final String KEY_SHOPLAT = "shoplat";
	public static final String KEY_SHOPLONG = "shoplong";
	public static final String KEY_IS_SHOPNEW = "shopnew_one";
	public static final String KEY_SHOPUSERNAME = "shopusername";
	public static final String KEY_SHOPMOBILE = "shopmobile";
	public static final String KEY_RECEIPTIMG = "receiptimg";
	public static final String KEY_SHOPIMG1 = "shopimg1";
	public static final String KEY_SHOPIMG2 = "shopimg2";
	public static final String KEY_SHOPIMG3 = "shopimg3";

	private static final String CREATE_MYPROFILETABLE = "CREATE TABLE "
			+ TABLE_MYPROFILE + "(" + KEY_PHONE1 + " TEXT, " + KEY_PHONE2
			+ " TEXT, " + KEY_PHONE3 + " TEXT, " + KEY_PHONE4 + " TEXT, "
			+ KEY_PHARMA_NAME + " TEXT, " + KEY_ADDRESS + " TEXT, " + KEY_OWNER
			+ " TEXT, " + KEY_EMAIL + " TEXT NOT NULL, " + KEY_WEBSITE
			+ " TEXT, " + KEY_OPEN_TIME + " TEXT, " + KEY_CLOSE_TIME
			+ " TEXT, " + KEY_DELIVER_TIME + " TEXT, " + KEY_MIN_PURCHASE
			+ " TEXT, " + KEY_LAT + " TEXT, " + KEY_LONG + " TEXT, "
			+ KEY_PHOTO1 + " BLOB, " + KEY_PHOTO2 + " BLOB, " + KEY_PHOTO3
			+ " BLOB, " + KEY_PHOTO4 + " BLOB, " + KEY_DATE + " TEXT, "
			+ KEY_IS_NEW + " TEXT, " + KEY_ROW_ID
			+ " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_IS_DELIVERY
			+ " TEXT, " + KEY_LAND + " TEXT, " + KEY_BREAKSTART + " TEXT, "
			+ KEY_BREAKEND + " TEXT, " + KEY_STATE + " TEXT, " + KEY_PINCODE
			+ " TEXT, " + KEY_AREA + " TEXT, " + KEY_DELIVERYCGE + " TEXT"
			+ ")";
	
	//capture 

	private static final String CREATE_SHOPTABLE = "CREATE TABLE "
			+ TABLE_CAPTUREPHARMACY + "(" + KEY_SHOPLAT + " TEXT, "
			+ KEY_SHOPLONG + " TEXT, " + KEY_SHOPUSERNAME + " TEXT, "
			+ KEY_SHOPMOBILE + " TEXT, " + KEY_IS_SHOPNEW + " TEXT, "
			+ KEY_SHOPROW_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ KEY_RECEIPTIMG + " BLOB, " + KEY_SHOPIMG1 + " BLOB, "
			+ KEY_SHOPIMG2 + " BLOB, " + KEY_SHOPIMG3 + " BLOB" + ")";

	public DatabaseHelper(Context context) {

		super(context, DATABASE_NAME, null, DATABASE_VERSION);

	}

	@Override
	public void onCreate(SQLiteDatabase db) {

		// db.execSQL("CREATE TABLE " + TABLE_MYPROFILE + "(" + KEY_PHONE1
		// + " TEXT, " + KEY_PHONE2 + " TEXT, " + KEY_PHONE3 + " TEXT, "
		// + KEY_PHONE4 + " TEXT, " + KEY_PHARMA_NAME + " TEXT, "
		// + KEY_ADDRESS + " TEXT, " + KEY_OWNER + " TEXT, " + KEY_EMAIL
		// + " TEXT NOT NULL, " + KEY_WEBSITE + " TEXT, " + KEY_OPEN_TIME
		// + " TEXT, " + KEY_CLOSE_TIME + " TEXT, " + KEY_DELIVER_TIME
		// + " TEXT, " + KEY_MIN_PURCHASE + " TEXT, " + KEY_LAT
		// + " TEXT, " + KEY_LONG + " TEXT, " + KEY_PHOTO1 + " BLOB, "
		// + KEY_PHOTO2 + " BLOB, " + KEY_PHOTO3 + " BLOB, " + KEY_PHOTO4
		// + " BLOB, " + KEY_DATE + " TEXT, " + KEY_IS_NEW + " TEXT, "
		// + KEY_ROW_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
		// + KEY_IS_DELIVERY + " TEXT, " + KEY_LAND + " TEXT, "
		// + KEY_BREAKSTART + " TEXT, " + KEY_BREAKEND + " TEXT, "
		// + KEY_STATE + " TEXT, " + KEY_PINCODE + " TEXT, " + KEY_AREA
		// + " TEXT, " + KEY_DELIVERYCGE + " TEXT" + ");");

		// db.execSQL("CREATE TABLE " + TABLE_CAPTUREPHARMACY + "(" +
		// KEY_SHOPLAT
		// + " TEXT, " + KEY_SHOPLONG + " TEXT, " + KEY_SHOPUSERNAME
		// + " TEXT, " + KEY_SHOPMOBILE + " TEXT, " + KEY_IS_SHOPNEW
		// + " TEXT, " + KEY_SHOPROW_ID
		// + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_RECEIPTIMG
		// + " BLOB, " + KEY_SHOPIMG1 + " BLOB, " + KEY_SHOPIMG2
		// + " BLOB, " + KEY_SHOPIMG3 + " BLOB, " + ");");

		db.execSQL(CREATE_MYPROFILETABLE);
		db.execSQL(CREATE_SHOPTABLE);

		Log.d("Created", "Table");

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

		db.execSQL("DROP TABLE IF EXISTS " + TABLE_MYPROFILE);
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_CAPTUREPHARMACY);

		onCreate(db);

	}

}
