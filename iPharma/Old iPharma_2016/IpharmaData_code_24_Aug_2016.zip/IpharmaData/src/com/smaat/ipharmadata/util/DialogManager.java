package com.smaat.ipharmadata.util;

import java.util.Random;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.smaat.ipharmadata.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

public class DialogManager {

	static Dialog alertOptionDialog;
	static AlertDialog mAlertDialog;
	static Dialog mProgressDialog;

	public static Dialog showDialog(final Activity context, String message,
			String buttonText, final Class<?> move, final int animFrom,
			final int animTo) {

		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setCancelable(false);

		builder.setTitle(R.string.app_name)
				.setMessage(message)
				.setPositiveButton(buttonText,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								if (move == null) {
									alertOptionDialog.cancel();
								} else {
									Intent cacheIntent = new Intent(context,
											move);

									context.startActivity(cacheIntent);
									// Setting screen transition
									context.overridePendingTransition(animFrom,
											animTo);
									context.finish();
								}
							}
						});

		alertOptionDialog = builder.show();

		alertOptionDialog.show();
		return alertOptionDialog;
	}

	public static Dialog showPopUpDialog(final Context context,
			final DialogMangerCallback dialoginterface, final String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setCancelable(false);

		builder.setTitle(R.string.app_name)
				.setMessage(message)
				.setPositiveButton(
						context.getResources().getString(R.string.ok),
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								alertOptionDialog.cancel();
								dialoginterface.onOkclick();
							}
						});

		alertOptionDialog = builder.show();

		alertOptionDialog.show();
		return alertOptionDialog;
	}

	public static Dialog callSessionId(final Activity context, String message,
			String buttonText, final Class<?> move, final int animFrom,
			final int animTo) {

		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setCancelable(false);

		builder.setTitle(R.string.app_name)
				.setMessage(message)
				.setPositiveButton(buttonText,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								if (move == null) {
									// LoginActivity.getSessionId();
									alertOptionDialog.cancel();
								} else {
									// LoginActivity.getSessionId();
									Intent cacheIntent = new Intent(context,
											move);
									context.startActivity(cacheIntent);
									// Setting screen transition
									context.overridePendingTransition(animFrom,
											animTo);
									context.finish();
								}

							}
						});

		alertOptionDialog = builder.show();

		alertOptionDialog.show();
		return alertOptionDialog;
	}

	public static Dialog showMessageDialog(final Context mContext,
			String message, String btnTxt) {

		AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

		builder.setTitle(R.string.app_name)
				.setMessage(message)
				.setPositiveButton(btnTxt,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {

								alertOptionDialog.cancel();

							}
						});

		alertOptionDialog = builder.show();

		alertOptionDialog.show();

		return alertOptionDialog;
	}

	public static void showMessageDialogwithCallback(final Context mContext,
			String message, final DialogMangerCallback mCallback) {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = new AlertDialog.Builder(mContext)
				.setTitle(R.string.app_name)
				.setMessage(message)
				.setPositiveButton(mContext.getString(R.string.ok),
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								mCallback.onOkclick();

							}
						}).setIcon(android.R.drawable.ic_dialog_alert).show();
	}

	public static void showToast(Context context, String message) {

		Toast.makeText(context, message, Toast.LENGTH_LONG).show();
	}

	public static Dialog showDialogAlert(final Activity mContext,
			String alertMessage, String btnText, String btnText1,
			final Class<?> move, final int animFrom, final int animTo) {

		AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

		builder.setTitle(R.string.app_name)
				.setMessage(alertMessage)
				.setPositiveButton(btnText,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {

								// ((Activity) mContext).finish();
								if (move == null) {
									alertOptionDialog.cancel();
								} else {
									Intent cacheIntent = new Intent(mContext,
											move);

									mContext.startActivity(cacheIntent);
									// Setting screen transition
									mContext.overridePendingTransition(
											animFrom, animTo);
									// mContext.finish();
								}

							}
						})
				.setNegativeButton(btnText1,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								alertOptionDialog.cancel();
							}
						});

		alertOptionDialog = builder.show();

		alertOptionDialog.show();
		return alertOptionDialog;
	}

	public static ProgressDialog getProgressDialog(Context activity, int message) {
		ProgressDialog dialog = new ProgressDialog(activity);

		dialog.setIndeterminate(true);
		dialog.setCancelable(false);
		dialog.setInverseBackgroundForced(false);
		dialog.setCanceledOnTouchOutside(false);
		dialog.setTitle(message);

		return dialog;
	}

	public static void showDialogOkCancel(Context context, String title,
			String message, final DialogMangerCallback mCallback) {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = new AlertDialog.Builder(context)
				.setTitle(title)
				.setMessage(message)
				.setPositiveButton(context.getString(R.string.later),
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								mCallback.onOkclick();

							}
						})
				.setNegativeButton(context.getString(R.string.yes),
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {

								mCallback.onCancelclick();

							}
						}).setIcon(android.R.drawable.ic_dialog_alert).show();
	}

	public static void showProgress(Context context) {
		if (mProgressDialog != null && mProgressDialog.isShowing()) {
			mProgressDialog.dismiss();
		}
		try {
			mProgressDialog = getLoadingDialog(context, R.layout.progress);
			mProgressDialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static Dialog getLoadingDialog(Context mContext, int mLay) {

		Dialog mDialog = getDialog(mContext, mLay);
		mDialog.setCancelable(true);
		mDialog.setCanceledOnTouchOutside(false);

		return mDialog;
	}

	public static Dialog getDialog(Context mContext, int mLayout) {

		Dialog mDialog = new Dialog(mContext);
		mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mDialog.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		mDialog.setContentView(mLayout);
		mDialog.getWindow().setBackgroundDrawable(
				new ColorDrawable(Color.TRANSPARENT));
		mDialog.setCancelable(true);
		mDialog.setCanceledOnTouchOutside(true);

		return mDialog;
	}
	public static void hideProgress(Context context) {
		if (mProgressDialog != null && mProgressDialog.isShowing()) {
			mProgressDialog.dismiss();
		}
	}
	
	public static double touchlongtitude, curLat, curLong;
	public static double foundLongitude, foundLatitude;
	protected LocationManager locationManager;
	protected LocationListener locationListener;
	private GoogleMap mGoogleMap;
	private double mCurrentLatitude;
	private double mCurrentLongitude;
	public  void showMap(final BaseActivity mContext){
		Button save, cancel;
	final Dialog alertOptionDialog = getDialog(mContext, R.layout.dialog_map);
	       
	        
	        cancel = (Button) alertOptionDialog.findViewById(R.id.cancel_btn);
			save = (Button) alertOptionDialog.findViewById(R.id.save);

			save.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					clearMap(mContext);
					mContext.onLatLongUpdate();
					alertOptionDialog.cancel();
				}
			});
			cancel.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					clearMap(mContext);
					alertOptionDialog.cancel();

				}
			});

			initializeMap(mContext);
			
			alertOptionDialog.show();

		
	}
	
	private void clearMap(BaseActivity mContext){
		Fragment fragment = (mContext.getFragmentManager()
                .findFragmentById(R.id.map_view));
        FragmentTransaction ft = mContext.getFragmentManager()
                .beginTransaction();
        ft.remove(fragment);
        ft.commitAllowingStateLoss();
	}
	
	private void initializeMap(BaseActivity mContext){
		if (mGoogleMap == null) {

			mGoogleMap = ((MapFragment) mContext.getFragmentManager().findFragmentById(
					R.id.map_view)).getMap();

			if (mGoogleMap == null) {
				Toast.makeText(mContext,
						"Sorry! unable to create maps", Toast.LENGTH_SHORT)
						.show();
			} else {
				mGoogleMap.setMyLocationEnabled(true);
				mGoogleMap.getUiSettings().setZoomControlsEnabled(false);
				mGoogleMap.getUiSettings().setCompassEnabled(true);
				mGoogleMap.getUiSettings().setMyLocationButtonEnabled(true);
				mGoogleMap.getUiSettings().setRotateGesturesEnabled(true);
				mGoogleMap.setOnMapClickListener(new OnMapClickListener() {
					public void onMapClick(LatLng point) {
						curLat = point.latitude;
						curLong = point.longitude;
						mGoogleMap.clear();
						MarkerOptions marker = new MarkerOptions().position(
								new LatLng(point.latitude, point.longitude))
								.title("New Marker");
						mGoogleMap.addMarker(marker);
					}
				});
				

				if (Build.VERSION.SDK_INT > 17) {
					getCurrentLocation("isFirst",mContext);

				} else {
					LocationManager locationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
					Criteria criteria = new Criteria();

					Location location = locationManager
							.getLastKnownLocation(locationManager
									.getBestProvider(criteria, false));
					if (location != null) {
						mGoogleMap.animateCamera(CameraUpdateFactory
								.newLatLngZoom(
										new LatLng(location.getLatitude(),
												location.getLongitude()), 13));

						// create marker
						MarkerOptions marker1 = new MarkerOptions()
								.position(new LatLng(location.getLatitude(),
										location.getLongitude()));

						// Changing marker icon
						// marker.icon(BitmapDescriptorFactory
						// .fromResource(R.drawable.current_location));

						// adding marker
						mGoogleMap.addMarker(marker1);
						System.out.println("Latitude :::"
								+ location.getLatitude() + "Longitude:::"
								+ location.getLongitude());
					}
				}

			}
		}
	}
	
	private void getCurrentLocation(String string, BaseActivity mContext) {
		GPSTracker tracker = new GPSTracker(mContext);
		if (tracker.canGetLocation() == false) {
			tracker.showSettingsAlert();
		} else {
			mCurrentLatitude = tracker.getLatitude();
			mCurrentLongitude = tracker.getLongitude();
		}

		if (string.equalsIgnoreCase("isFirst")) {
			LatLng currentLatLong = new LatLng(mCurrentLatitude,
					mCurrentLongitude);

			getLatLong(mCurrentLatitude, mCurrentLongitude);
		}

	}

	private void getLatLong(double latitude, double longitude) {
		for (int i = 0; i < 10; i++) {

			Random random = new Random();
			double radiusInDegrees = 15 / 111000f;

			double u = random.nextDouble();
			double v = random.nextDouble();
			double w = radiusInDegrees * Math.sqrt(u);
			double t = 20 * Math.PI * v;
			double x = w * Math.cos(t);
			double y = w * Math.sin(t);
			double new_x = x / Math.cos(latitude);
			double new_y = y / Math.cos(longitude);

			foundLongitude = new_x + longitude;
			foundLatitude = new_y + latitude;
			System.out.println("Longitude: " + foundLongitude + "  Latitude: "
					+ foundLatitude);

		}
		LatLng newLatLng1 = null;
		newLatLng1 = new LatLng(mCurrentLatitude, mCurrentLongitude);

		mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(newLatLng1));
		mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

		// create marker
		MarkerOptions marker = new MarkerOptions().position(new LatLng(
				mCurrentLatitude, mCurrentLongitude));

		// Changing marker icon
		// marker.icon(BitmapDescriptorFactory
		// .fromResource(R.drawable.current_location));

		// adding marker
		mGoogleMap.addMarker(marker);

	}
	
	
}
