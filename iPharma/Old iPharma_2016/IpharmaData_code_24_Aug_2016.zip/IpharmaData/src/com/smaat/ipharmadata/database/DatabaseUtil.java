package com.smaat.ipharmadata.database;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.smaat.ipharmadata.db.model.Image;
import com.smaat.ipharmadata.db.model.ShopDetails;
import com.smaat.ipharmadata.db.model.ShopImage;
import com.smaat.ipharmadata.db.model.UserDetails;
import com.smaat.ipharmadata.util.DialogManager;

public class DatabaseUtil {

	private SQLiteDatabase db;
	DatabaseHelper dbhelper = null;

	public void open() throws SQLiteException {

		db = DatabaseManager.getInstance().openDatabase();
	}

	public DatabaseUtil(Context context) {
		dbhelper = new DatabaseHelper(context);
	}

	public void close() {
		DatabaseManager.getInstance().closeDatabase();
	}

	public int myProfileInsert(Context context, String phone1, String phone2,
			String phone3, String phone4, String phar_name, String address,
			String ownernme, String email, String website, String opentime,
			String closetime, String deliverytime, String minipur,
			String isNew, double latitude, double longitude, byte[] photo1,
			byte[] photo2, byte[] photo3, byte[] photo4, String date,
			String isdelivery, String landmark, String Device,
			String Breakstarttime, String Breakendtime, String state,
			String pincode, String area, String deliverycharge, String refno) {

		open();
		int count = 0;
		try {

			ContentValues values = new ContentValues();
			values.put(DatabaseHelper.KEY_PHONE1, phone1);
			values.put(DatabaseHelper.KEY_PHONE2, phone2);
			values.put(DatabaseHelper.KEY_PHONE3, phone3);
			values.put(DatabaseHelper.KEY_PHONE4, phone4);
			values.put(DatabaseHelper.KEY_OWNER, ownernme);
			values.put(DatabaseHelper.KEY_ADDRESS, address);
			values.put(DatabaseHelper.KEY_EMAIL, email);
			values.put(DatabaseHelper.KEY_PHARMA_NAME, phar_name);
			values.put(DatabaseHelper.KEY_WEBSITE, website);
			values.put(DatabaseHelper.KEY_OPEN_TIME, opentime);
			values.put(DatabaseHelper.KEY_CLOSE_TIME, closetime);
			values.put(DatabaseHelper.KEY_DELIVER_TIME, deliverytime);
			values.put(DatabaseHelper.KEY_MIN_PURCHASE, minipur);
			values.put(DatabaseHelper.KEY_IS_NEW, isNew);
			values.put(DatabaseHelper.KEY_LAT, latitude);
			values.put(DatabaseHelper.KEY_LONG, longitude);
			values.put(DatabaseHelper.KEY_PHOTO1, photo1);
			values.put(DatabaseHelper.KEY_PHOTO2, photo2);
			values.put(DatabaseHelper.KEY_PHOTO3, photo3);
			values.put(DatabaseHelper.KEY_PHOTO4, photo4);
			values.put(DatabaseHelper.KEY_DATE, date);
			values.put(DatabaseHelper.KEY_IS_DELIVERY, isdelivery);
			values.put(DatabaseHelper.KEY_LAND, landmark);
			values.put(DatabaseHelper.KEY_BREAKSTART, Breakstarttime);
			values.put(DatabaseHelper.KEY_BREAKEND, Breakendtime);
			values.put(DatabaseHelper.KEY_STATE, state);
			values.put(DatabaseHelper.KEY_LAND, landmark);
			values.put(DatabaseHelper.KEY_PINCODE, pincode);
			values.put(DatabaseHelper.KEY_DELIVERYCGE, deliverycharge);
			values.put(DatabaseHelper.KEY_AREA, area);

			try {
				count += ((db.insertWithOnConflict(
						DatabaseHelper.TABLE_MYPROFILE, null, values,
						SQLiteDatabase.CONFLICT_IGNORE)) == -1) ? 0 : 1;
				System.out.println(count);
				if (count > 0) {
					DialogManager.showMessageDialog(context,
							"Saved Successfully", "Ok");

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return count;

	}

	public int InsertShopdetails(Context context, String mUsernameStr,
			String mPhoneNo, double mLatidude, double mLongitude,
			byte[] mReceiptimgbyt, byte[] mShopbyt1, byte[] mShopbyt2,
			byte[] mShopbyt3, String isShopnew) {

		open();
		int count = 0;

		try {

			ContentValues values = new ContentValues();
			values.put(DatabaseHelper.KEY_SHOPUSERNAME, mUsernameStr);
			values.put(DatabaseHelper.KEY_SHOPMOBILE, mPhoneNo);
			values.put(DatabaseHelper.KEY_SHOPLAT, mLatidude);
			values.put(DatabaseHelper.KEY_SHOPLONG, mLongitude);
			values.put(DatabaseHelper.KEY_RECEIPTIMG, mReceiptimgbyt);
			values.put(DatabaseHelper.KEY_SHOPIMG1, mShopbyt1);
			values.put(DatabaseHelper.KEY_SHOPIMG2, mShopbyt2);
			values.put(DatabaseHelper.KEY_SHOPIMG3, mShopbyt3);
			values.put(DatabaseHelper.KEY_IS_SHOPNEW, isShopnew);

			try {
				count += ((db.insertWithOnConflict(
						DatabaseHelper.TABLE_CAPTUREPHARMACY, null, values,
						SQLiteDatabase.CONFLICT_IGNORE)) == -1) ? 0 : 1;
				System.out.println(count);
				if (count > 0) {
					// DialogManager.showMessageDialog(context,
					// "Saved Successfully", "Ok");

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return count;

	}

	public ArrayList<ShopDetails> getShopprofile() {
		ArrayList<ShopDetails> shopList = new ArrayList<ShopDetails>();
		open();
		String query;

		query = "select * from " + DatabaseHelper.TABLE_CAPTUREPHARMACY
				+ " where " + DatabaseHelper.KEY_IS_SHOPNEW + "='" + "0" + "'";
		Cursor cursor = db.rawQuery(query, null);
		try {
			if (cursor != null) {
				if (cursor.getCount() > 0) {
					cursor.moveToFirst();
					do {
						ShopDetails shop = new ShopDetails();

						shop.setUsername(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_SHOPUSERNAME)));
						shop.setLatitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_SHOPLAT)));
						shop.setLongitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_SHOPLONG)));
						shop.setPhonenum(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_SHOPMOBILE)));
						shop.setRowid(cursor.getInt(cursor
								.getColumnIndex(DatabaseHelper.KEY_SHOPROW_ID)));

						ShopImage image = new ShopImage();
						image.setReceiptimg(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_RECEIPTIMG)));
						image.setShopimage1(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_SHOPIMG1)));
						image.setShopimage2(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_SHOPIMG2)));
						image.setShopimage3(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_SHOPIMG3)));
						

						shop.setImage(image);

						shopList.add(shop);
					} while (cursor.moveToNext());
				}
			}
		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
			e.printStackTrace();
		} finally {
			if (cursor != null)
				cursor.close();
			close();
		}
		return shopList;
	}

	public ArrayList<UserDetails> getProfile() {
		ArrayList<UserDetails> userList = new ArrayList<UserDetails>();
		open();
		String query;

		query = "select * from " + DatabaseHelper.TABLE_MYPROFILE + " where "
				+ DatabaseHelper.KEY_IS_NEW + "='" + "0" + "'";
		Cursor cursor = db.rawQuery(query, null);
		try {
			if (cursor != null) {
				if (cursor.getCount() > 0) {
					cursor.moveToFirst();
					do {
						UserDetails user = new UserDetails();

						user.setPhone1(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE1)));
						user.setPhone2(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE2)));
						user.setPhone3(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE3)));
						user.setPhone_number(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE4)));

						user.setPharmacy_name(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHARMA_NAME)));

						user.setAddress(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_ADDRESS)));

						user.setOwner_name(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_OWNER)));

						user.setEmail_id(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_EMAIL)));
						user.setWebsite(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_WEBSITE)));
						user.setOpening_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_OPEN_TIME)));
						user.setClosing_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_CLOSE_TIME)));
						user.setDelivery_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_DELIVER_TIME)));
						user.setMin_purchase(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_MIN_PURCHASE)));
						user.setHome_delivery(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_IS_DELIVERY)));
						user.setDatetime(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_DATE)));
						user.setLatitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_LAT)));
						user.setLongitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_LONG)));
						user.setIsNew(cursor.getInt(cursor
								.getColumnIndex(DatabaseHelper.KEY_IS_NEW)));
						user.setRowid(cursor.getInt(cursor
								.getColumnIndex(DatabaseHelper.KEY_ROW_ID)));
						user.setLandmark(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_LAND)));

						Image image = new Image();
						image.setImage1(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO1)));

						image.setImage2(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO2)));
						image.setImage3(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO3)));

						image.setImage4(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO4)));
						user.setPhone4(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE4)));
						user.setBreakstarttime(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_BREAKSTART)));
						user.setBreakendtime(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_BREAKEND)));

						user.setDeliverycharge(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_DELIVERYCGE)));
						user.setPincode(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PINCODE)));
						user.setState(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_STATE)));
						user.setArea(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_AREA)));

						user.setImage(image);

						userList.add(user);
					} while (cursor.moveToNext());
				}
			}
		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
			e.printStackTrace();
		} finally {
			if (cursor != null)
				cursor.close();
			close();
		}
		return userList;
	}

	public void UpdateTable(int i) {
		try {

			ContentValues values = new ContentValues();

			values.put(DatabaseHelper.KEY_IS_NEW, "1");

			open();

			db.update(DatabaseHelper.TABLE_MYPROFILE, values,
					DatabaseHelper.KEY_IS_NEW + " = ?" + "AND "
							+ DatabaseHelper.KEY_ROW_ID + " = ?", new String[] {
							"0", String.valueOf(i) });

		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
			e.printStackTrace();
		}

		finally {
			close();
		}
	}

	public void deleteUser() {
		try {

			open();

			db.delete(DatabaseHelper.TABLE_MYPROFILE, DatabaseHelper.KEY_IS_NEW
					+ " = ?", new String[] { "1" });
		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
			e.printStackTrace();
		}

		finally {
			close();
		}
	}

	public ArrayList<UserDetails> getPushProfile() {
		ArrayList<UserDetails> userList = new ArrayList<UserDetails>();
		open();
		String query;

		query = "select * from " + DatabaseHelper.TABLE_MYPROFILE + " where "
				+ DatabaseHelper.KEY_IS_NEW + "='" + "1" + "'";
		Cursor cursor = db.rawQuery(query, null);
		try {
			if (cursor != null) {
				if (cursor.getCount() > 0) {
					cursor.moveToFirst();
					do {
						UserDetails user = new UserDetails();

						user.setPhone1(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE1)));
						user.setPhone2(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE2)));
						user.setPhone3(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE3)));
						user.setPhone_number(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE4)));

						user.setPharmacy_name(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHARMA_NAME)));

						user.setAddress(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_ADDRESS)));

						user.setOwner_name(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_OWNER)));

						user.setEmail_id(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_EMAIL)));
						user.setWebsite(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_WEBSITE)));
						user.setOpening_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_OPEN_TIME)));
						user.setClosing_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_CLOSE_TIME)));
						user.setDelivery_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_DELIVER_TIME)));
						user.setMin_purchase(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_MIN_PURCHASE)));
						user.setHome_delivery(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_IS_NEW)));
						user.setDatetime(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_DATE)));
						user.setLatitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_LAT)));
						user.setLongitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_LONG)));
						user.setIsDelivery(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_IS_DELIVERY)));
						user.setRowid(cursor.getInt(cursor
								.getColumnIndex(DatabaseHelper.KEY_ROW_ID)));
						user.setLandmark(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_LAND)));

						Image image = new Image();
						image.setImage1(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO1)));

						image.setImage2(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO2)));
						image.setImage3(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO3)));

						image.setImage4(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO4)));
						user.setImage(image);
						System.out.println("Image1:::" + image.getImage1()
								+ "Image2:::" + image.getImage2() + "Image3::"
								+ image.getImage3() + "Image4:::"
								+ image.getImage4());

						userList.add(user);
					} while (cursor.moveToNext());
				}
			}
		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
			e.printStackTrace();
		} finally {
			if (cursor != null)
				cursor.close();
			close();
		}
		return userList;
	}

	public void UpdateShopTable(int rowid) {

		try {

			ContentValues values = new ContentValues();

			values.put(DatabaseHelper.KEY_IS_SHOPNEW, "1");

			open();

			db.update(DatabaseHelper.TABLE_CAPTUREPHARMACY, values,
					DatabaseHelper.KEY_IS_SHOPNEW + " = ?" + "AND "
							+ DatabaseHelper.KEY_SHOPROW_ID + " = ?",
					new String[] { "0", String.valueOf(rowid) });

		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
			e.printStackTrace();
		}

		finally {
			close();
		}

	}

	public void deleteShopTable() {

		try {

			open();

			db.delete(DatabaseHelper.TABLE_CAPTUREPHARMACY,
					DatabaseHelper.KEY_IS_SHOPNEW + " = ?",
					new String[] { "1" });
		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
			e.printStackTrace();
		}

		finally {
			close();
		}

	}
}
