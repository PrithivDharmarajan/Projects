package com.smaat.ipharmadata.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.smaat.ipharmadata.R;
import com.smaat.ipharmadata.util.AppConstants;
import com.smaat.ipharmadata.util.BaseActivity;
import com.smaat.ipharmadata.util.DialogManager;
import com.smaat.ipharmadata.util.DialogMangerCallback;
import com.smaat.ipharmadata.util.GlobalMethods;

public class LoginScreen extends BaseActivity implements DialogMangerCallback {

	private EditText mRefNumberEdit, mUserNameEdit, mPhoneNumberEdit;
	private String mRefNumber, mUserName, mPhoneNumber,mDeviceID;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		ViewGroup mViewGroup = (ViewGroup) findViewById(R.id.parent_layout);
		setupUI(mViewGroup);
		initView();
		mDeviceID=getIMEI(this);

	}

	public String getIMEI(Context context) {

		TelephonyManager mngr = (TelephonyManager) context
				.getSystemService(context.TELEPHONY_SERVICE);
		String imei = mngr.getDeviceId();
		return imei;

	}

	public void initView() {
		mRefNumberEdit = (EditText) findViewById(R.id.ref_num_edit);
		mUserNameEdit = (EditText) findViewById(R.id.user_name_edit);
		mPhoneNumberEdit = (EditText) findViewById(R.id.phone_num_edit);
	}

	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.save:
			validateFields();
			break;

		}
	}

	private void validateFields() {

		mRefNumber = mRefNumberEdit.getText().toString().trim();
		mUserName = mUserNameEdit.getText().toString().trim();
		mPhoneNumber = mPhoneNumberEdit.getText().toString().trim();

		if (mRefNumber.equalsIgnoreCase("") || mRefNumber.length() < 0) {
			DialogManager.showPopUpDialog(LoginScreen.this, this,
					"Please enter your reference number");
		} else if (mUserName.equalsIgnoreCase("") || mUserName.length() < 0) {
			DialogManager.showPopUpDialog(LoginScreen.this, this,
					"Please enter your username");

		} else if (mPhoneNumber.equalsIgnoreCase("")
				|| mPhoneNumber.length() < 0) {
			DialogManager.showPopUpDialog(LoginScreen.this, this,
					"Please enter your phone number");
		} else if (mPhoneNumber.length() < 10) {
			DialogManager.showPopUpDialog(LoginScreen.this, this,
					"Please enter your valid phone number");
		} else {
			saveToPreference();
		}

	}

	private void saveToPreference() {
		GlobalMethods.storeValuetoPreference(LoginScreen.this,
				GlobalMethods.STRING_PREFERENCE, AppConstants.REFERENCE_NUMBER,
				mRefNumber);

		GlobalMethods.storeValuetoPreference(LoginScreen.this,
				GlobalMethods.STRING_PREFERENCE, AppConstants.USER_NAME,
				mUserName);

		GlobalMethods.storeValuetoPreference(LoginScreen.this,
				GlobalMethods.STRING_PREFERENCE, AppConstants.PHONE_NUMBER,
				mPhoneNumber);

		GlobalMethods.storeValuetoPreference(LoginScreen.this,
				GlobalMethods.STRING_PREFERENCE, AppConstants.IS_FIRST,
				"IS_NEXT");
		GlobalMethods.storeValuetoPreference(LoginScreen.this,
				GlobalMethods.STRING_PREFERENCE, AppConstants.DEVICE_ID,
				mDeviceID);
		
		Intent mIntent = new Intent(this, DetailsActivity.class);
		startActivity(mIntent);
		finish();

	}

	@Override
	public void onItemclick(String SelctedItem, int pos) {

	}

	@Override
	public void onOkclick() {
		/**
		 * Close Dialog
		 */
	}

	@Override
	public void onCancelclick() {
		
	}

}
