package com.smaat.ipharmadata.activity;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.json.JSONObject;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.androidquery.callback.AjaxCallback;
import com.androidquery.callback.AjaxStatus;
import com.google.android.gms.maps.GoogleMap;
import com.google.gson.Gson;
import com.smaat.ipharmadata.R;
import com.smaat.ipharmadata.database.DatabaseUtil;
import com.smaat.ipharmadata.db.model.ShopDetails;
import com.smaat.ipharmadata.db.model.UserDetails;
import com.smaat.ipharmadata.fragment.TimePickerFragment;
import com.smaat.ipharmadata.service.CommonResponse;
import com.smaat.ipharmadata.service.RequestIntentService.GsonTransformer;
import com.smaat.ipharmadata.util.AppConstants;
import com.smaat.ipharmadata.util.BaseActivity;
import com.smaat.ipharmadata.util.DialogManager;
import com.smaat.ipharmadata.util.DialogMangerCallback;
import com.smaat.ipharmadata.util.GPSTracker;
import com.smaat.ipharmadata.util.GlobalMethods;
import com.smaat.ipharmadata.util.ProfileImageSelectionUtil;

public class DetailsActivity extends BaseActivity implements
		DialogMangerCallback, TimePickerFragment.NoticeDialogListener {
	private RadioButton mRadioYes, mRadioNo;
	LinearLayout mDeliveryLayout;
	// private Button mSave;
	DatabaseUtil db;
	private EditText mPharName, mOwnerName, mAddress, mWebsite, mEmail,
			mPhone1, mPhone2, mPhone3, mPhone4, mDelivertime, mMinPur,
			mLandMark, mAreaEdit, mPincodeEdit, mStateEdit,
			mDeliveryChargeEdit;
	ArrayList<UserDetails> mUserDetails;
	TextView mNewCount, mTotalCount;
	private int selectedImageId;
	ArrayList<ShopDetails> mShopdetails;

	ImageView mPhoto1, mPhoto2, mPhoto3, mPhoto4;
	private Bitmap profileImage;
	byte[] photobyte1, photobyte2, photobyte3, photobyte4;
	TextView mOpentime, mCloseTime, mBreakTimeStart, mBreakTimeEnd;
	private TimePickerFragment fragmentTimePicker;
	private String StartTime = "", EndTime = "", BreakStart = "",
			BreakEnd = "";
	private String pharname, ownername, address, website, email, phone1,
			phone2, phone3, phone4, deliverytime, minpur, opentime, closetime,
			land, mArea, mPincode, mState, mDeliveryCharge, mBreakTimeStartStr,
			mBreakTimeEndStr;

	String radioStr = "";
	String total;
	private double touchlatitude;
	private double touchlongtitude, curLat, curLong;
	protected LocationManager locationManager;
	protected LocationListener locationListener;
	private Location l;
	private TextView mLat, mLong, mLocate;
	private GoogleMap mGoogleMap;
	private boolean isMapMove;
	private double mCurrentLatitude;
	private double mCurrentLongitude;
	private String mMarkerType;
	public EditText mUserName, mPhone;
	String username, phone;
	private GPSTracker gps;
	public static double foundLongitude, foundLatitude;
	private String mRefNo, mDevice, mUsernameStr, mPhoneNo;
	private String mLatstr = "", mLongstr = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_details);

		ViewGroup mViewGroup = (ViewGroup) findViewById(R.id.parent_layout);
		Window window = this.getWindow();
		window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
				| WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		db = new DatabaseUtil(this);
		mUserDetails = db.getProfile();
		mShopdetails = db.getShopprofile();

		total = (String) GlobalMethods.getValueFromPreference(
				DetailsActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.rowcount);
		mRefNo = (String) GlobalMethods.getValueFromPreference(
				DetailsActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.REFERENCE_NUMBER);
		mDevice = (String) GlobalMethods.getValueFromPreference(
				DetailsActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.DEVICE_ID);
		mUsernameStr = (String) GlobalMethods.getValueFromPreference(
				DetailsActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.USER_NAME);
		mPhoneNo = (String) GlobalMethods.getValueFromPreference(
				DetailsActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.PHONE_NUMBER);

		hideSoftKeyboard(DetailsActivity.this);
		setupUI(mViewGroup);

		// getCurrentLocation("isFirst");

		
		gps = new GPSTracker(DetailsActivity.this);
		// check if GPS enabled
		if (gps.canGetLocation()) {
			foundLatitude = gps.getLatitude();
			foundLongitude = gps.getLongitude();
			// \n is for new line
			// Toast.makeText(
			// getApplicationContext(),
			// "Your Location is - \nLat: " + foundLatitude + "\nLong: "
			// + foundLongitude, Toast.LENGTH_LONG).show();

		} else {
			// can't get location
			// GPS or Network is not enabled
			// Ask user to enable GPS/network in settings
			gps.showSettingsAlert();
		}
		
		initView();

		if (mUserDetails.size() == 0 && mShopdetails.size() == 0) {
			mNewCount.setText(String.valueOf(mUserDetails.size()));
		} else if (mUserDetails.size() > 0 && mShopdetails.size() > 0) {
			int total = mUserDetails.size() + mShopdetails.size();
			mNewCount.setText(String.valueOf(String.valueOf(total)));
		} else {
			if (mUserDetails.size() != 0) {
				mNewCount.setText(String.valueOf(String.valueOf(mUserDetails
						.size())));

			} else if (mShopdetails.size() != 0) {
				mNewCount.setText(String.valueOf(String.valueOf(mShopdetails
						.size())));
			} else {
				mNewCount.setText("0");
			}
		}

	}

	public void initView() {
		mRadioYes = (RadioButton) findViewById(R.id.radio_yes);
		mRadioNo = (RadioButton) findViewById(R.id.radio_no);
		mDeliveryLayout = (LinearLayout) findViewById(R.id.delivery_time_layout);
		// mSave = (Button) findViewById(R.id.save);
		mPharName = (EditText) findViewById(R.id.phar_name_edit);
		mOwnerName = (EditText) findViewById(R.id.owner_name_edit);
		mAddress = (EditText) findViewById(R.id.address_edit);
		mWebsite = (EditText) findViewById(R.id.website_edit);
		mEmail = (EditText) findViewById(R.id.email_edit);
		mPhone1 = (EditText) findViewById(R.id.phone_num_edit1);
		mPhone2 = (EditText) findViewById(R.id.phone_num_edit2);
		mPhone3 = (EditText) findViewById(R.id.phone_num_edit3);
		mPhone4 = (EditText) findViewById(R.id.phone_num_edit4);
		mOpentime = (TextView) findViewById(R.id.open_time_edit);
		mCloseTime = (TextView) findViewById(R.id.close_time_edit);

		mDelivertime = (EditText) findViewById(R.id.delivery_edit);
		mMinPur = (EditText) findViewById(R.id.min_pur_edit);
		mNewCount = (TextView) findViewById(R.id.new_count);
		mLandMark = (EditText) findViewById(R.id.landmark_edit);
		mTotalCount = (TextView) findViewById(R.id.total_count);

		mAreaEdit = (EditText) findViewById(R.id.area_edit);
		mPincodeEdit = (EditText) findViewById(R.id.pin_code_edit);
		mStateEdit = (EditText) findViewById(R.id.state_edit);
		mDeliveryChargeEdit = (EditText) findViewById(R.id.delivery_charge_edit);

		mBreakTimeStart = (TextView) findViewById(R.id.break_time_start_edit);
		mBreakTimeEnd = (TextView) findViewById(R.id.break_time_end_edit);

		mStateEdit.setText(getString(R.string.tamilnadu));

		if (total != null && !total.equalsIgnoreCase("")) {
			mTotalCount.setText(total);
		}

		mPhoto1 = (ImageView) findViewById(R.id.photo1);
		mPhoto2 = (ImageView) findViewById(R.id.photo2);
		mPhoto3 = (ImageView) findViewById(R.id.photo3);
		mPhoto4 = (ImageView) findViewById(R.id.photo4);
		radioStr = "0";

		mLat = (TextView) findViewById(R.id.latitude);
		mLong = (TextView) findViewById(R.id.longitude);
		if (foundLatitude != 0.00) {
			mLatstr = String.format("%.4f", foundLatitude);
			mLat.setText(mLatstr);
		} else {
			mLatstr = String.format("%.4f", DialogManager.curLat);
			mLat.setText(mLatstr);
		}
		if (foundLongitude != 0.00) {
			// mLong.setText(String.format("%.4f", curLong));
			mLongstr = String.format("%.4f", foundLongitude);

			mLong.setText(mLongstr);
		} else {
			mLongstr = String.format("%.4f", DialogManager.curLong);

			mLong.setText(mLongstr);
		}
		// mLat.setText(String.format("%.4f", curLat));
		// mLong.setText(String.format("%.4f", curLong));

		mRadioYes.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				if (isChecked) {
					mDeliveryLayout.setVisibility(View.VISIBLE);
					mRadioYes.setChecked(true);
					mRadioNo.setChecked(false);
					radioStr = "1";
				}
			}
		});
		mRadioNo.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				if (isChecked) {
					mDeliveryLayout.setVisibility(View.GONE);
					mRadioYes.setChecked(false);
					mRadioNo.setChecked(true);
					radioStr = "0";

				}
			}
		});

	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public void onClick(View v) {
		int id = v.getId();
		Bundle args;
		switch (id) {
		case R.id.back_arrow:
			onBackPressed();
			break;
		case R.id.save:
			pharname = mPharName.getText().toString().trim();
			ownername = mOwnerName.getText().toString().trim();
			phone1 = mPhone1.getText().toString().trim();
			phone2 = mPhone2.getText().toString().trim();
			phone3 = mPhone3.getText().toString().trim();
			phone4 = mPhone4.getText().toString().trim();
			address = mAddress.getText().toString().trim();
			email = mEmail.getText().toString().trim();
			opentime = mOpentime.getText().toString().trim();
			closetime = mCloseTime.getText().toString().trim();
			deliverytime = mDelivertime.getText().toString().trim();
			minpur = mMinPur.getText().toString().trim();
			website = mWebsite.getText().toString().trim();
			land = mLandMark.getText().toString().trim();

			mArea = mAreaEdit.getText().toString().trim();
			mPincode = mPincodeEdit.getText().toString().trim();
			mState = mStateEdit.getText().toString().trim();
			mDeliveryCharge = mDeliveryChargeEdit.getText().toString().trim();
			mBreakTimeStartStr = mBreakTimeStart.getText().toString().trim();
			mBreakTimeEndStr = mBreakTimeEnd.getText().toString().trim();

			if (ValidRegister()) {
				showUserDetialsDialog();
			}
			break;
		case R.id.push:
			mUserDetails = db.getProfile();
			mShopdetails = db.getShopprofile();

			if (mUserDetails != null && mUserDetails.size() > 0) {

				setPassDialog(username, phone);
				// TODO
			} else if (mShopdetails != null && mShopdetails.size() > 0) {
				setPassDialog(username, phone);
			}

			else {
				DialogManager.showMessageDialog(DetailsActivity.this,
						"You don't have any new items to push", "Ok");
			}

			break;
		case R.id.photo1:
			showImage(id);
			break;
		case R.id.photo2:
			showImage(id);
			break;
		case R.id.photo3:
			showImage(id);
			break;
		case R.id.photo4:
			showImage(id);
			break;
		case R.id.open_time_edit:

			fragmentTimePicker = new TimePickerFragment();

			args = new Bundle();
			args.putString("inputtime", StartTime);
			args.putString("inputfield", "starttime");
			fragmentTimePicker.setArguments(args);
			fragmentTimePicker.show(getFragmentManager(), "Time picker Start");
			break;
		case R.id.close_time_edit:
			fragmentTimePicker = new TimePickerFragment();

			args = new Bundle();
			args.putString("inputtime", EndTime);
			args.putString("inputfield", "endtime");
			fragmentTimePicker.setArguments(args);
			fragmentTimePicker.show(getFragmentManager(), "Time picker Start");
			break;
		case R.id.break_time_start_edit:

			fragmentTimePicker = new TimePickerFragment();

			args = new Bundle();
			args.putString("inputtime", BreakStart);
			args.putString("inputfield", "Breakstarttime");
			fragmentTimePicker.setArguments(args);
			fragmentTimePicker.show(getFragmentManager(), "Time picker Start");
			break;
		case R.id.break_time_end_edit:
			fragmentTimePicker = new TimePickerFragment();

			args = new Bundle();
			args.putString("inputtime", BreakEnd);
			args.putString("inputfield", "Breakendtime");
			fragmentTimePicker.setArguments(args);
			fragmentTimePicker.show(getFragmentManager(), "Time picker Start");
			break;

		case R.id.locate:
			new DialogManager().showMap(this);
			break;

		case R.id.capture_pharmacy:
			Intent intent = new Intent(DetailsActivity.this,
					CapturePharmacyActivity.class);

			startActivity(intent);
			finish();

		default:
			break;
		}
	}

	private boolean ValidRegister() {

		if (mPharName.getText().toString().trim().isEmpty()
				&& mPharName.getText().toString().trim().length() < 1
				&& mPharName.getText().toString().trim().equalsIgnoreCase("")) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter pharmacy name");
			return false;
		}
		if (mAddress.getText().toString().trim().isEmpty()
				&& mAddress.getText().toString().trim().length() < 1
				&& mAddress.getText().toString().trim().equalsIgnoreCase("")) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter address");
			return false;
		}
		if (mOwnerName.getText().toString().trim().isEmpty()
				&& mOwnerName.getText().toString().trim().length() < 1
				&& mOwnerName.getText().toString().trim().equalsIgnoreCase("")) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter owner name");
			return false;
		}
		if (mAreaEdit.getText().toString().trim().isEmpty()) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter Area");
			return false;
		}
		if (mPincodeEdit.getText().toString().trim().isEmpty()) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter Pincode");
			return false;
		}
		if (mOpentime.getText().toString().trim()
				.equalsIgnoreCase("Select Time")) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please select openning time");
			return false;
		}
		if (mCloseTime.getText().toString().trim()
				.equalsIgnoreCase("Select Time")) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please select Close time");
			return false;
		}
		if (mLandMark.getText().toString().trim().isEmpty()) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter Landmark");
			return false;
		}

		if (mPhone1.getText().toString().trim().isEmpty()
				&& mPhone1.getText().toString().trim().equalsIgnoreCase("")) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter Mobile number 1");
			return false;
		}

		if (mPhone2.getText().toString().trim().length() > 1
				&& mPhone2.getText().toString().trim().length() < 9) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter mobile number with 10 digit");
			return false;
		}
		if (mPhone1.getText().toString().trim().length() > 1
				&& mPhone1.getText().toString().trim().length() < 9) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter mobile number with 10 digit");
			return false;
		}
		if (photobyte1 == null && photobyte2 == null && photobyte3 == null
				&& photobyte4 == null) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please capture any one photo");
			return false;
		}

		return true;
	}

	@Override
	public void onItemclick(String SelctedItem, int pos) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onOkclick() {
		// TODO Auto-generated method stub

	}

	public void clearText() {
		mPharName.setText("");
		mOwnerName.setText("");
		mPhone1.setText("");
		mPhone2.setText("");
		mPhone3.setText("");
		mPhone4.setText("");
		mAddress.setText("");
		radioStr = "0";
		mWebsite.setText("");
		mEmail.setText("");
		mOpentime.setText("Select Time");
		mCloseTime.setText("Select Time");
		mAreaEdit.setText("");
		mPincodeEdit.setText("");
		mBreakTimeEnd.setText("Select Time");
		mBreakTimeStart.setText("Select Time");
		mDeliveryChargeEdit.setText("0");
		mDelivertime.setText("");
		mDeliveryLayout.setVisibility(View.GONE);
		mMinPur.setText("");
		mRadioNo.setChecked(true);
		mPhoto1.setImageDrawable(null);
		mPhoto2.setImageDrawable(null);
		mPhoto3.setImageDrawable(null);
		mPhoto4.setImageDrawable(null);
		photobyte1 = null;
		photobyte2 = null;
		photobyte3 = null;
		photobyte4 = null;
		mLandMark.setText("");

	}

	public void showUserDetialsDialog() {

		mDialog = new Dialog(DetailsActivity.this);
		mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mDialog.setContentView(R.layout.dialog_profile_details);

		mDialog.getWindow().setBackgroundDrawable(
				new ColorDrawable(Color.TRANSPARENT));
		WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
		wmlp.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;

		mDialog.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
						| WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		TextView PharName = (TextView) mDialog
				.findViewById(R.id.phar_name_edit);
		TextView OwnerName = (TextView) mDialog
				.findViewById(R.id.owner_name_edit);
		TextView Address = (TextView) mDialog.findViewById(R.id.address_edit);
		TextView Website = (TextView) mDialog.findViewById(R.id.website_edit);
		TextView Email = (TextView) mDialog.findViewById(R.id.email_edit);
		TextView Phone1 = (TextView) mDialog.findViewById(R.id.phone1);
		TextView Phone2 = (TextView) mDialog.findViewById(R.id.phone2);
		TextView Phone3 = (TextView) mDialog.findViewById(R.id.phone3);
		TextView Phone4 = (TextView) mDialog.findViewById(R.id.phone4);
		TextView landmark = (TextView) mDialog.findViewById(R.id.land_edit);
		TextView Opentime = (TextView) mDialog
				.findViewById(R.id.open_time_edit);
		TextView CloseTime = (TextView) mDialog
				.findViewById(R.id.close_time_edit);

		TextView MinPur = (TextView) mDialog.findViewById(R.id.min_pur_edit);
		Button mConfirm = (Button) mDialog.findViewById(R.id.confirm);
		Button mCancel = (Button) mDialog.findViewById(R.id.cancel);
		TextView isDelivery = (TextView) mDialog.findViewById(R.id.yes_text);
		TextView deliveryTime = (TextView) mDialog.findViewById(R.id.within);

		TextView area = (TextView) mDialog.findViewById(R.id.area_edit);
		TextView pincode = (TextView) mDialog.findViewById(R.id.pincode_edit);
		TextView state = (TextView) mDialog.findViewById(R.id.state_edit);

		TextView breakStart = (TextView) mDialog
				.findViewById(R.id.break_start_edit);
		TextView breakEnd = (TextView) mDialog
				.findViewById(R.id.break_end_edit);
		TextView deliverChr = (TextView) mDialog
				.findViewById(R.id.deliver_char_edit);

		PharName.setText(pharname);
		OwnerName.setText(ownername);
		Address.setText(address);
		Phone1.setText(phone1);
		Phone2.setText(phone2);
		Phone3.setText(phone3);
		Phone4.setText(phone4);
		landmark.setText(land);
		area.setText(mArea);
		pincode.setText(mPincode);
		state.setText(mState);

		deliverChr.setText(mDeliveryCharge);

		Email.setText(email);
		Website.setText(website);
		if (!opentime.equalsIgnoreCase("Select Time")) {
			Opentime.setText(opentime);
		}
		if (!closetime.equalsIgnoreCase("Select Time")) {
			CloseTime.setText(closetime);
		}

		if (mBreakTimeStartStr.equalsIgnoreCase("Select Time")) {
			mBreakTimeStartStr = "";
		}
		if (mBreakTimeEndStr.equalsIgnoreCase("Select Time")) {
			mBreakTimeEndStr = "";
		}

		breakStart.setText(mBreakTimeStartStr);
		breakEnd.setText(mBreakTimeEndStr);

		MinPur.setText(minpur);
		isDelivery.setText(radioStr.equalsIgnoreCase("0") ? "No" : "Yes");
		deliveryTime.setText(deliverytime);

		ImageView Photo1 = (ImageView) mDialog.findViewById(R.id.photo1);
		ImageView Photo4 = (ImageView) mDialog.findViewById(R.id.photo4);
		ImageView Photo2 = (ImageView) mDialog.findViewById(R.id.photo2);
		ImageView Photo3 = (ImageView) mDialog.findViewById(R.id.photo3);
		if (photobyte1 != null) {
			Bitmap bitmap1 = BitmapFactory.decodeByteArray(photobyte1, 0,
					photobyte1.length);
			aq().id(R.id.photo1).getImageView().setImageBitmap(bitmap1);
			Photo1.setImageBitmap(bitmap1);
		}
		if (photobyte2 != null) {
			Bitmap bitmap2 = BitmapFactory.decodeByteArray(photobyte2, 0,
					photobyte2.length);
			aq().id(R.id.photo2).getImageView().setImageBitmap(bitmap2);
			Photo2.setImageBitmap(bitmap2);
		}
		if (photobyte3 != null) {
			Bitmap bitmap3 = BitmapFactory.decodeByteArray(photobyte3, 0,
					photobyte3.length);
			aq().id(R.id.photo3).getImageView().setImageBitmap(bitmap3);
			Photo3.setImageBitmap(bitmap3);
		}
		if (photobyte4 != null) {
			Bitmap bitmap4 = BitmapFactory.decodeByteArray(photobyte4, 0,
					photobyte4.length);
			aq().id(R.id.photo4).getImageView().setImageBitmap(bitmap4);
			Photo4.setImageBitmap(bitmap4);
		}

		mConfirm.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				Calendar c = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss", Locale.US);
				String strDate = sdf.format(c.getTime());

				db.myProfileInsert(DetailsActivity.this, mPhone1.getText()
						.toString().trim(),
						mPhone2.getText().toString().trim(), mPhone3.getText()
								.toString().trim(), mPhone4.getText()
								.toString().trim(), mPharName.getText()
								.toString().trim(), mAddress.getText()
								.toString().trim(), mOwnerName.getText()
								.toString().trim(), mEmail.getText().toString()
								.trim(), mWebsite.getText().toString().trim(),
						StartTime, EndTime, mDelivertime.getText().toString()
								.trim(), mMinPur.getText().toString().trim(),
						"0", Double.valueOf(mLat.getText().toString().trim()),
						Double.valueOf(mLong.getText().toString().trim()),
						photobyte1, photobyte2, photobyte3, photobyte4,
						strDate, radioStr, mLandMark.getText().toString()
								.trim(), mDevice, mBreakTimeStartStr,
						mBreakTimeEndStr, mState, mPincode, mArea,
						mDeliveryCharge, mRefNo);
				clearText();
				mUserDetails = db.getProfile();
				if (mUserDetails.size() == 0 && mShopdetails.size() == 0) {
					mNewCount.setText(String.valueOf(mUserDetails.size()));
				} else if (mUserDetails.size() > 0 && mShopdetails.size() > 0) {
					int total = mUserDetails.size() + mShopdetails.size();
					mNewCount.setText(String.valueOf(String.valueOf(total)));
				} else {
					if (mUserDetails.size() > 0) {
						mNewCount.setText(String.valueOf(String
								.valueOf(mUserDetails.size())));

					} else {
						mNewCount.setText(String.valueOf(String
								.valueOf(mShopdetails.size())));
					}
				}

				mDialog.dismiss();
			}
		});
		mCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mDialog.dismiss();
			}
		});

		mDialog.show();
	}

	public void setPassDialog(final String username, final String phone) {

		mDialog = new Dialog(this);
		mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mDialog.setContentView(R.layout.pass);

		mDialog.getWindow().setBackgroundDrawable(
				new ColorDrawable(Color.TRANSPARENT));
		WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
		wmlp.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;

		mDialog.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
						| WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		mDialog.setCancelable(true);
		final EditText mPass = (EditText) mDialog.findViewById(R.id.pass_edit);
		Button mAdd = (Button) mDialog.findViewById(R.id.ok);

		mAdd.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mPass.getText().toString().trim()
						.equalsIgnoreCase(getString(R.string.ipharma))) {
					mDialog.dismiss();
					mUserDetails = db.getProfile();

					if (mUserDetails != null && mUserDetails.size() > 0) {

						callCout = 0;
						callService(mUserDetails.get(callCout),
								DetailsActivity.this, username, phone);

					} else {
						callCout = 0;
						if (mShopdetails != null && mShopdetails.size() > 0) {
							callServiceforShopdetails(
									mShopdetails.get(callCout),
									DetailsActivity.this, username, phone);

						}
					}
				} else {
					Toast.makeText(DetailsActivity.this,
							"Please enter valid password", Toast.LENGTH_SHORT)
							.show();
				}

			}

		});
		mDialog.show();

	}

	public void showconfirmDialog() {

		mDialog = new Dialog(this);
		mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mDialog.setContentView(R.layout.dialog_username);

		mDialog.getWindow().setBackgroundDrawable(
				new ColorDrawable(Color.TRANSPARENT));
		WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
		wmlp.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;

		mDialog.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
						| WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		mDialog.setCancelable(true);
		mUserName = (EditText) mDialog.findViewById(R.id.user_edit);
		mPhone = (EditText) mDialog.findViewById(R.id.phone_edit);
		Button mOK = (Button) mDialog.findViewById(R.id.user_ok);

		mOK.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (validDetails()) {
					mDialog.dismiss();
					username = mUserName.getText().toString().trim();
					phone = mPhone.getText().toString().trim();
					setPassDialog(username, phone);

				}

			}

		});

		mDialog.show();
	}

	private void showImage(int id) {
		selectedImageId = id;
		ProfileImageSelectionUtil.showOption(DetailsActivity.this);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == ProfileImageSelectionUtil.CAMERA
				|| requestCode == ProfileImageSelectionUtil.GALLERY) {
			try {

				if (resultCode == RESULT_OK) {

					if (requestCode == ProfileImageSelectionUtil.CAMERA
							|| requestCode == ProfileImageSelectionUtil.GALLERY) {

						Bitmap image = ProfileImageSelectionUtil.getImage(data,
								this);

						if (image != null) {
							if (requestCode == ProfileImageSelectionUtil.CAMERA) {
								if (ProfileImageSelectionUtil.isUriTrue) {
									image = ProfileImageSelectionUtil
											.getCorrectOrientationImage(this,
													data.getData(), image);
								} else {
									image = ProfileImageSelectionUtil
											.getCorrectOrientationImage(this,
													image);
								}
							} else {

								Uri selectedImage = data.getData();

								image = ProfileImageSelectionUtil
										.getCorrectOrientationImage(this,
												selectedImage, image);
							}
							ByteArrayOutputStream oututStream = new ByteArrayOutputStream();
							switch (selectedImageId) {
							case R.id.photo1:
								profileImage = image;
								aq().id(R.id.photo1).getImageView()
										.setImageBitmap(image);
								if (profileImage != null) {

									profileImage.compress(
											Bitmap.CompressFormat.PNG, 50,
											oututStream);
									photobyte1 = (oututStream).toByteArray();

								}
								break;

							case R.id.photo2:
								profileImage = image;
								aq().id(R.id.photo2).getImageView()
										.setImageBitmap(image);
								if (profileImage != null) {

									profileImage.compress(
											Bitmap.CompressFormat.PNG, 50,
											oututStream);
									photobyte2 = (oututStream).toByteArray();

								}
								break;
							case R.id.photo3:
								profileImage = image;
								aq().id(R.id.photo3).getImageView()
										.setImageBitmap(image);
								if (profileImage != null) {

									profileImage.compress(
											Bitmap.CompressFormat.PNG, 50,
											oututStream);
									photobyte3 = (oututStream).toByteArray();

								}
								break;
							case R.id.photo4:
								profileImage = image;
								aq().id(R.id.photo4).getImageView()
										.setImageBitmap(image);
								if (profileImage != null) {

									profileImage.compress(
											Bitmap.CompressFormat.PNG, 50,
											oututStream);
									photobyte4 = (oututStream).toByteArray();

								}
								break;
							default:
								break;
							}
						} else {

							DialogManager.showDialog(this,
									"Image not available",
									getString(R.string.ok), null, 0, 0);
						}
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public void onTimeSelected(DialogFragment dialog, String selectedTime,
			String selectedField) {
		if (selectedField.equals("starttime"))
			StartTime = selectedTime;

		if (selectedField.equals("endtime"))
			EndTime = selectedTime;

		if (selectedField.equals("Breakendtime"))
			BreakEnd = selectedTime;
		if (selectedField.equals("Breakstarttime"))
			BreakStart = selectedTime;

		mOpentime.setText(StartTime);
		mCloseTime.setText(EndTime);
		mBreakTimeStart.setText(BreakStart);
		mBreakTimeEnd.setText(BreakEnd);

	}

	int callCout = 0;

	public void callService(UserDetails userDetails, final DetailsActivity act,
			String username, String phone) {

		DialogManager.showProgress(this);

		HashMap<String, Object> params = new HashMap<String, Object>();
		final String url = "http://smaatapps.com/iPharma/index.php/ipharmadetails";

		params.put("userid", "1");
		params.put("phone1", userDetails.getPhone1());
		params.put("phone2", userDetails.getPhone2());
		params.put("phone3", userDetails.getPhone3());
		params.put("phone_number", userDetails.getPhone_number());
		params.put("pharmacy_name", userDetails.getPharmacy_name());
		params.put("address", userDetails.getAddress());
		params.put("owner_name", userDetails.getOwner_name());
		params.put("website", userDetails.getWebsite());
		params.put("email_id", userDetails.getEmail_id());
		params.put("landmark", userDetails.getLandmark());
		params.put("opening_time", userDetails.getOpening_time());
		params.put("closing_time", userDetails.getClosing_time());
		params.put("delivery_time", userDetails.getDelivery_time());
		params.put("min_purchase", userDetails.getMin_purchase());
		params.put("home_delivery", userDetails.getHome_delivery());
		params.put("latitude", String.valueOf(userDetails.getLatitude()));
		params.put("longitude", String.valueOf(userDetails.getLongitude()));
		params.put("datetime", String.valueOf(userDetails.getDatetime()));
		params.put("image1", userDetails.getImage().getImage1());
		params.put("image2", userDetails.getImage().getImage2());
		params.put("image3", userDetails.getImage().getImage3());
		params.put("image4", userDetails.getImage().getImage4());
		params.put("username", mUsernameStr);
		params.put("mobile", mPhoneNo);
		params.put("phone4", userDetails.getPhone3());
		params.put("Breakstarttime", userDetails.getBreakstarttime());
		params.put("Breakendtime", userDetails.getBreakendtime());
		params.put("Device", mDevice);
		params.put("state", userDetails.getState());
		params.put("pincode", userDetails.getPincode());
		params.put("deliverycharge", userDetails.getDeliverycharge());
		params.put("refno", mRefNo);
		params.put("area", userDetails.getArea());

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq().transformer(t)

		.ajax(url, params, JSONObject.class, new AjaxCallback<JSONObject>() {
			public void callback(String url, JSONObject profile,
					AjaxStatus status) {

				if (profile != null) {

					try {
						CommonResponse obj = new Gson().fromJson(
								profile.toString(), CommonResponse.class);
						System.out.println("Profile:::" + profile.toString());

						act.onRequestCallBack(obj);
					} catch (Exception e) {
						e.printStackTrace();
						act.onRequestCallBack(null);
					}

				} else {
					act.onRequestCallBack(null);
				}

			}

		});
	}

	public void onRequestCallBack(CommonResponse response) {
		System.out.println("RESPONSE:::" + response);

		DialogManager.hideProgress(this);
		if (response != null) {
			if (response.getError_code().equalsIgnoreCase("1")) {

				db.UpdateTable(mUserDetails.get(callCout).getRowid());

				GlobalMethods.storeValuetoPreference(DetailsActivity.this,
						GlobalMethods.STRING_PREFERENCE, AppConstants.rowcount,
						response.getResult());

			}
		}

		total = (String) GlobalMethods.getValueFromPreference(
				DetailsActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.rowcount);
		mTotalCount.setText(total);

		callCout++;

		if (mUserDetails.size() > callCout) {
			callService(mUserDetails.get(callCout), DetailsActivity.this,
					username, phone);

		} else {

			mShopdetails = db.getShopprofile();

			if (mShopdetails != null && mShopdetails.size() > 0) {

				callCout = 0;
				callServiceforShopdetails(mShopdetails.get(callCout),
						DetailsActivity.this, username, phone);

			} else {
				if (response != null) {
					if (response.getError_code().equalsIgnoreCase("1")) {

						DialogManager
								.showMessageDialog(
										DetailsActivity.this,
										"Data has been successfully uploaded to server",
										"ok");
					}
				} else {
					DialogManager.showMessageDialog(DetailsActivity.this,
							"Failed to upload", "ok");
				}
			}
		}

		db.deleteUser();
		mUserDetails = db.getProfile();
		System.out.println("USer Count:::" + mUserDetails.size());

		if (mUserDetails.size() == 0 && mShopdetails.size() == 0) {
			mNewCount.setText(String.valueOf(mUserDetails.size()));
		} else if (mUserDetails.size() > 0 && mShopdetails.size() > 0) {
			int total = mUserDetails.size() + mShopdetails.size();
			mNewCount.setText(String.valueOf(String.valueOf(total)));
		} else {
			if (mUserDetails.size() != 0) {
				mNewCount.setText(String.valueOf(String.valueOf(mUserDetails
						.size())));

			} else if (mShopdetails.size() != 0) {
				mNewCount.setText(String.valueOf(String.valueOf(mShopdetails
						.size())));
			} else {
				mNewCount.setText("0");
			}
		}

		total = (String) GlobalMethods.getValueFromPreference(
				DetailsActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.rowcount);
		mTotalCount.setText(total);

	}

	// call api for shopdetails
	private void callServiceforShopdetails(ShopDetails shopDetails,
			final DetailsActivity detailsActivity, String username2,
			String phone5) {

		DialogManager.showProgress(this);

		HashMap<String, Object> params = new HashMap<String, Object>();
		final String url = "http://smaatapps.com/iPharma/index.php/TempParmacyCollection";

		params.put("userid", "1");
		params.put("username", mUsernameStr);
		params.put("mobile", mPhoneNo);
		params.put("latitude", mLatstr);
		params.put("longitude", mLongstr);
		params.put("receipt_image", shopDetails.getImage().getReceiptimg());
		params.put("shop_image1", shopDetails.getImage().getShopimage1());
		params.put("shop_image2", shopDetails.getImage().getShopimage2());
		params.put("shop_image3", shopDetails.getImage().getShopimage3());

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq().transformer(t)

		.ajax(url, params, JSONObject.class, new AjaxCallback<JSONObject>() {
			public void callback(String url, JSONObject profile,
					AjaxStatus status) {

				if (profile != null) {

					try {
						CommonResponse obj = new Gson().fromJson(
								profile.toString(), CommonResponse.class);
						System.out.println("Profile:::" + profile.toString());

						detailsActivity.onShopRequestCallBack(obj);
					} catch (Exception e) {
						e.printStackTrace();
						detailsActivity.onShopRequestCallBack(null);
					}

				} else {
					detailsActivity.onShopRequestCallBack(null);
				}

			}

		});

	}

	public void onShopRequestCallBack(CommonResponse response) {

		DialogManager.hideProgress(this);

		if (response != null) {
			if (response.getError_code().equalsIgnoreCase("1")) {

				db.UpdateShopTable(mShopdetails.get(callCout).getRowid());

				GlobalMethods.storeValuetoPreference(DetailsActivity.this,
						GlobalMethods.STRING_PREFERENCE, AppConstants.rowcount,
						response.getResult());

			}
		}

		total = (String) GlobalMethods.getValueFromPreference(
				DetailsActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.rowcount);
		mTotalCount.setText(total);

		callCout++;

		if (mShopdetails.size() > callCout) {
			callServiceforShopdetails(mShopdetails.get(callCout),
					DetailsActivity.this, username, phone);

		} else {
		}
		db.deleteShopTable();
		mShopdetails = db.getShopprofile();
		if (mUserDetails.size() == 0 && mShopdetails.size() == 0) {
			mNewCount.setText(String.valueOf(mUserDetails.size()));
		} else if (mUserDetails.size() > 0 && mShopdetails.size() > 0) {
			int total = mUserDetails.size() + mShopdetails.size();
			mNewCount.setText(String.valueOf(String.valueOf(total)));
		} else {
			if (mUserDetails.size() != 0) {
				mNewCount.setText(String.valueOf(String.valueOf(mUserDetails
						.size())));

			} else if (mShopdetails.size() != 0) {
				mNewCount.setText(String.valueOf(String.valueOf(mShopdetails
						.size())));
			} else {
				mNewCount.setText("0");
			}
		}

		total = (String) GlobalMethods.getValueFromPreference(
				DetailsActivity.this, GlobalMethods.STRING_PREFERENCE,
				AppConstants.rowcount);
		mTotalCount.setText(total);
		if (response != null) {
			if (response.getError_code().equalsIgnoreCase("1")) {

				DialogManager.showMessageDialog(DetailsActivity.this,
						"Data has been successfully uploaded to server", "ok");
			}
		} else {
			DialogManager.showMessageDialog(DetailsActivity.this,
					"Failed to upload", "ok");
		}
	}

	/*
	 * @Override public void onRequestSuccess(Object responseObj) { // TODO
	 * Auto-generated method stub super.onRequestSuccess(responseObj);
	 * CommonResponse resultObj = (CommonResponse) responseObj;
	 * 
	 * // if (resultObj.getError_code().equalsIgnoreCase("1")) {
	 * DialogManager.showPopUpDialog(this, this, resultObj.getMsg()); // } }
	 */

	public boolean validDetails() {

		if (mUserName.getText().toString().trim().isEmpty()
				&& mUserName.getText().toString().trim().length() < 1
				&& mUserName.getText().toString().trim().equalsIgnoreCase("")) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter username");
			return false;
		}
		if (mPhone.getText().toString().trim().isEmpty()
				&& mPhone.getText().toString().trim().length() < 1
				&& mPhone.getText().toString().trim().equalsIgnoreCase("")) {
			DialogManager.showPopUpDialog(DetailsActivity.this, this,
					"Please enter phone number");
			return false;
		}
		return true;

	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		finish();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		
		

		mUserDetails = db.getProfile();
		mShopdetails = db.getShopprofile();
		if (mUserDetails.size() == 0 && mShopdetails.size() == 0) {
			mNewCount.setText(String.valueOf(mUserDetails.size()));
		} else if (mUserDetails.size() > 0 && mShopdetails.size() > 0) {
			int total = mUserDetails.size() + mShopdetails.size();
			mNewCount.setText(String.valueOf(String.valueOf(total)));
		} else {
			if (mUserDetails.size() != 0) {
				mNewCount.setText(String.valueOf(String.valueOf(mUserDetails
						.size())));

			} else if (mShopdetails.size() != 0) {
				mNewCount.setText(String.valueOf(String.valueOf(mShopdetails
						.size())));
			} else {
				mNewCount.setText("0");
			}
		}
	}
	
	@Override
	protected void onLatLongUpdate() {
		if (DialogManager.curLat != 0.00) {
			mLatstr = String.format("%.4f", DialogManager.curLat);
			mLat.setText(mLatstr);
		} else {
			mLatstr = String.format("%.4f", foundLatitude);
			mLat.setText(mLatstr);
		}
		if (DialogManager.curLong != 0.00) {
			// mLong.setText(String.format("%.4f", curLong));
			mLongstr = String.format("%.4f", DialogManager.curLong);

			mLong.setText(mLongstr);
		} else {
			mLongstr = String.format("%.4f", foundLongitude);

			mLong.setText(mLongstr);
		}
	}

	@Override
	public void onCancelclick() {
		// TODO Auto-generated method stub

	}
	
	

}
