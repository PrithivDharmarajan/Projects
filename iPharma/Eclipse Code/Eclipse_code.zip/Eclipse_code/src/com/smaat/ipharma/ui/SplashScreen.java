package com.smaat.ipharma.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.smaat.ipharma.BaseActivity;
import com.smaat.ipharma.R;
import com.smaat.ipharma.util.AppConstants;
import com.smaat.ipharma.util.GlobalMethods;

public class SplashScreen extends BaseActivity {
	public static long Splash = 3000;
	private static final int STOPSPLASH = 0;

	protected Object mRegId;
	@SuppressWarnings("unused")
	private Context mContext;
	private String UserID;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		Message msg = new Message();
		msg.what = STOPSPLASH;
		mContext = SplashScreen.this;
		splashHandler.sendMessageDelayed(msg, Splash);
	}

	@SuppressLint("HandlerLeak")
	private Handler splashHandler = new Handler() {

		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case STOPSPLASH:
				String tut_screen_shown = GlobalMethods
						.getTutorialShown(SplashScreen.this);
				UserID = GlobalMethods.getUserID(SplashScreen.this);
				if (tut_screen_shown
						.equalsIgnoreCase(AppConstants.FAILURE_CODE)) {
					Intent intent = new Intent(SplashScreen.this,
							TutorialScreen.class);
					startActivity(intent);
					finish();
				} else {
					if (UserID != null
							&& !UserID
									.equalsIgnoreCase(AppConstants.FAILURE_CODE)) {
						Intent intent = new Intent(SplashScreen.this,
								HomeScreen.class);

						AppConstants.FROMINTLOADMAP = AppConstants.FROMMAP;
						startActivity(intent);
						finish();
					} else {
						Intent intent = new Intent(SplashScreen.this,
								LoginActivity.class);
						startActivity(intent);
						finish();
					}
				}
				GlobalMethods.storeValuetoPreference(getApplication(),
						GlobalMethods.STRING_PREFERENCE,
						AppConstants.TUT_SCREEN, AppConstants.SUCCESS_CODE);
				break;

			default:
				break;
			}
		};
	};
}
