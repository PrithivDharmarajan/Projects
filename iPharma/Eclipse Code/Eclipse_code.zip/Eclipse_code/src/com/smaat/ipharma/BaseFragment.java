package com.smaat.ipharma;

import java.net.SocketTimeoutException;

import retrofit.RetrofitError;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.support.v4.app.Fragment;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.androidquery.AQuery;
import com.smaat.ipharma.util.DialogManager;
import com.smaat.ipharma.util.DialogMangerCallback;

public class BaseFragment extends Fragment implements DialogMangerCallback {
	private AQuery aq;
	public static Dialog mDialog;

	public void setupUI(View view) {

		if (!(view instanceof EditText)) {

			view.setOnTouchListener(new OnTouchListener() {

				public boolean onTouch(View v, MotionEvent event) {
					// hideSoftKeyboard(getActivity());
					return false;
				}

			});
		}
		if (view instanceof ViewGroup) {

			for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {

				View innerView = ((ViewGroup) view).getChildAt(i);

				setupUI(innerView);
			}
		}
	}

	public void showToast(Context fragment, String msg) {
		Toast.makeText(fragment, msg, Toast.LENGTH_SHORT).show();
	}
	
	public void setFont(ViewGroup group, Typeface font) {
		int count = group.getChildCount();
		View v;
		for (int i = 0; i < count; i++) {
			v = group.getChildAt(i);
			if (v instanceof TextView || v instanceof Button /* etc. */)
				((TextView) v).setTypeface(font);
			else if (v instanceof ViewGroup)
				setFont((ViewGroup) v, font);
		}
	}

	public AQuery aq() {
		if (aq == null) {
			aq = new AQuery(getActivity());
		}
		return aq;
	}

	public void hideSoftKeyboard(Context fragment) {
		try {
			if (fragment != null) {
				getActivity()
						.getWindow()
						.setSoftInputMode(
								WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
				InputMethodManager imm = (InputMethodManager) fragment
						.getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(getView().getWindowToken(), 0);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void onBackPressed() {

	}
	
	public void onRequestSuccess(Object responseObj) {

	}
	
	

	public void onRequestFailure(RetrofitError errorCode) {

		if (errorCode.getCause() instanceof SocketTimeoutException) {
//			DialogManager.showToast(getActivity(),
//					getString(R.string.connection_timeout));
		} else {
			DialogManager.showCustomAlertDialog(getActivity(),BaseFragment.this,
					getString(R.string.no_network));
		}

	}

	@Override
	public void onItemclick(String SelctedItem, int pos) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onOkclick() {
		// TODO Auto-generated method stub
		
	}

	
}
