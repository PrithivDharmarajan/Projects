package com.smaat.ipharma.util;

import android.content.Intent;
import android.graphics.Bitmap;

public interface ImageCallback {

	void imageDetails(Bitmap data);
}
