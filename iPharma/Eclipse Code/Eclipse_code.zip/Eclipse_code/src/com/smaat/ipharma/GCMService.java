package com.smaat.ipharma;

import java.util.Random;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.google.android.gcm.GCMBaseIntentService;
import com.smaat.ipharma.util.AppConstants;
import com.smaat.ipharma.util.GlobalMethods;

public class GCMService extends GCMBaseIntentService {

	private static final String TAG = "GCMIntentService";
	private JSONObject json;
	@SuppressWarnings("unused")
	private static String message = "", type = "", id = "", alert_msg = "",
			notification_id = "", chat_message = "", group_id = "";

	public GCMService() {
		super(AppConstants.SENDER_ID);
	}

	/**
	 * Method called on device registered
	 **/
	@Override
	protected void onRegistered(Context context, String registrationId) {
		Log.i(TAG, "Device registered: regId = " + registrationId);

		Log.d("NAME", "Registerd");

		GlobalMethods.storeValuetoPreference(context,
				GlobalMethods.STRING_PREFERENCE,
				AppConstants.pref_deviceReg_Id, registrationId);

		GlobalMethods.storeValuetoPreference(context,
				GlobalMethods.BOOLEAN_PREFERENCE,
				AppConstants.pref_device_reg_status, false);

		GlobalMethods
				.storeValuetoPreference(context,
						GlobalMethods.BOOLEAN_PREFERENCE,
						AppConstants.pref_device_id_changed,
						AppConstants.pref_deviceReg_Id
								.equalsIgnoreCase(registrationId) ? false
								: true);

	}

	/**
	 * Method called on device un registred
	 * */
	@Override
	protected void onUnregistered(Context context, String registrationId) {
		Log.i(TAG, "Device unregistered");

	}

	/**
	 * Method called on Receiving a new message
	 * */
	@Override
	protected void onMessage(Context context, Intent intent) {
		Log.i(TAG, "Received message");

		System.out.println("data:" + intent.getExtras());
		String intentStr = intent.getExtras().getString("message");

		if (intentStr != null && !intentStr.equalsIgnoreCase("")) {

			// {"msg":
			// "Mike tedt send a message request to you","type":"hotleadchat",
			// "user_id":"186","notification_user_id":"221"}

			try {
				json = new JSONObject(intentStr);
				message = json.getString("msg");
				type = json.getString("type");
				id = json.getString("id");
				notification_id = json.getString("notification_user_id");
				chat_message = json.getString("message");
				group_id = json.getString("group_id");
			} catch (JSONException e) {
				e.printStackTrace();
			}

//			if (type.equalsIgnoreCase("video")) {
//				Intent intent1 = new Intent().setClass(getApplicationContext(),
//						CallChatActivity.class);
//				intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//				intent1.putExtra("msg", message);
//				intent1.putExtra("type", type);
//				intent1.putExtra("chat_id", id);
//				startActivity(intent1);
//			} else if (type.equalsIgnoreCase("voice")) {
//				Intent intent1 = new Intent().setClass(getApplicationContext(),
//						CallChatActivity.class);
//				intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//				intent1.putExtra("msg", message);
//				intent1.putExtra("type", type);
//				intent1.putExtra("chat_id", id);
//				startActivity(intent1);
//			}
			// else if (type.equalsIgnoreCase("hotleadchat")) {
			// Intent chat_screen = new
			// Intent().setClass(getApplicationContext(),
			// FriendChatScreen.class);
			// chat_screen.putExtra("ids", id);
			// chat_screen.putExtra("names",
			// message.substring(message.lastIndexOf(" ") + 1));
			// chat_screen.putExtra("groupId", "");
			// chat_screen.putExtra("type", "group");
			// chat_screen.putExtra("enhanced_profile_ids", "1");
			// chat_screen.putExtra("from_call", "gcm");
			// startActivity(chat_screen);
			// }
//			else {
//				generateNotification(context, message);
//			}
		}
	}

	/**
	 * Method called on receiving a deleted message
	 * */
	@Override
	protected void onDeletedMessages(Context context, int total) {
		Log.i(TAG, "Received deleted messages notification");

	}

	/**
	 * Method called on Error
	 * */
	@Override
	public void onError(Context context, String errorId) {
		Log.i(TAG, "Received error: " + errorId);

	}

	@Override
	protected boolean onRecoverableError(Context context, String errorId) {
		// log message
		Log.i(TAG, "Received recoverable error: " + errorId);

		return super.onRecoverableError(context, errorId);
	}

	/**
	 * Issues a notification to inform the user that server has sent a message.
	 */
	@SuppressWarnings({ "deprecation", "unused" })
	private static void generateNotification(Context context, String message) {

		Random r = new Random();
		int notifiId = r.nextInt();

		int icon = R.drawable.app_icon;
		long when = System.currentTimeMillis();
		NotificationManager notificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		Notification notification = new Notification(icon, message, when);

		String title = context.getString(R.string.app_name);

		Class<?> target;

//		if (type.equalsIgnoreCase("friend")) {
//			target = FriendsPendingRequest.class;
//		} else if (type.equalsIgnoreCase("alertproperty")
//				|| type.equalsIgnoreCase("savedproperty")) {
//			target = PropertyDetailsActivity.class;
//		} else if (type.equalsIgnoreCase("schedule")) {
//			target = ScheduleMeetingActivity.class;
//		} else if (type.equalsIgnoreCase("request")) {
//			target = LeadsActivity.class;
//		} else if (type.equalsIgnoreCase("hotleadchat")) {
//			target = FriendChatScreen.class;
//		} else {
//
//			target = SplashScreen.class;
//		}
//		Intent notificationIntent = new Intent(context, target);
//		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
//				| Intent.FLAG_ACTIVITY_SINGLE_TOP);
//
//		notificationIntent.putExtra("ids", id);
//		notificationIntent.putExtra("names",
//				message.substring(message.lastIndexOf(" ") + 1));
//		notificationIntent.putExtra("groupId", group_id);
//		notificationIntent.putExtra("type", "group");
//		notificationIntent.putExtra("enhanced_profile_ids", "1");
//		notificationIntent.putExtra("from_call", "gcm");
//
//		notificationIntent.putExtra("CallFrom", "GCM");
//		notificationIntent.putExtra("PropertyId", id);
//		notificationIntent.putExtra("PropType", "");
//		notificationIntent.putExtra("ScheduleID", id);
//		PendingIntent intent = PendingIntent.getActivity(context,
//				"com.smaat.rentersblock".hashCode(), notificationIntent,
//				Intent.FLAG_ACTIVITY_NEW_TASK);
//		notification.setLatestEventInfo(context, title, message, intent);
//		notification.flags |= Notification.FLAG_AUTO_CANCEL;
//		notification.defaults |= Notification.DEFAULT_SOUND;
//		notification.defaults |= Notification.DEFAULT_VIBRATE;
//		notificationManager.notify(notifiId, notification);
	}
}
