package com.smaat.ipharma.webservice;

import java.util.Map;

import org.json.JSONObject;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxCallback;
import com.androidquery.callback.AjaxStatus;
import com.androidquery.callback.Transformer;
import com.google.gson.Gson;
import com.smaat.ipharma.BaseActivity;
import com.smaat.ipharma.BaseFragment;
import com.smaat.ipharma.entity.CommonResponse;
import com.smaat.ipharma.entity.Login;
import com.smaat.ipharma.model.MapResponse;
import com.smaat.ipharma.model.MyOrderRespose;
import com.smaat.ipharma.model.ProfileResponse;
import com.smaat.ipharma.model.ReviewsResponse;

public class ServieRequestHandler {

	private static final ServieRequestHandler instance = new ServieRequestHandler();

	public static ServieRequestHandler getInstance() {
		return instance;
	}

	private ServieRequestHandler() {

	}

	public static class GsonTransformer implements Transformer {

		public <T> T transform(String url, Class<T> type, String encoding,
				byte[] data, AjaxStatus status) {
			Gson g = new Gson();
			return g.fromJson(new String(data), type);
		}
	}

	public void globalResponseRecieve(String url, AQuery aq,
			final BaseActivity activity, Map<String, Object> params) {

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq.transformer(t)
		// .progress(DialogManager.LoadingDialog(activity))
				.ajax(url, params, JSONObject.class,
						new AjaxCallback<JSONObject>() {
							public void callback(String url,
									JSONObject profile, AjaxStatus status) {

								if (profile != null) {

									try {
										Object obj = new Gson().fromJson(
												profile.toString(),
												CommonResponse.class);

										activity.onRequestSuccess(obj);
									} catch (Exception e) {
										// activity.onRequestFailure(null);
										e.printStackTrace();
									}

								} else {
									activity.onRequestFailure(status.getCode()
											+ "");
								}

							}

						});
	}

	public void callwriteREview(String url, AQuery aq,
			final BaseFragment activity, Map<String, Object> params) {

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq.transformer(t)
		// .progress(DialogManager.LoadingDialog(activity.getActivity()))
				.ajax(url, params, JSONObject.class,
						new AjaxCallback<JSONObject>() {
							public void callback(String url,
									JSONObject profile, AjaxStatus status) {

								if (profile != null) {

									try {
										Object obj = new Gson().fromJson(
												profile.toString(),
												CommonResponse.class);

										activity.onRequestSuccess(obj);
									} catch (Exception e) {
										activity.onRequestFailure(null);
										e.printStackTrace();
									}

								} else {
									// activity.onRequestFailure(status.getCode()
									// + "");
								}

							}

						});
	}

	public void globalResponseRecieve(String url, AQuery aq,
			final BaseFragment activity, Map<String, Object> params) {

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq.transformer(t)
		// .progress(DialogManager.LoadingDialog(activity.getActivity()))
				.ajax(url, params, JSONObject.class,
						new AjaxCallback<JSONObject>() {
							public void callback(String url,
									JSONObject profile, AjaxStatus status) {

								if (profile != null) {

									try {
										Object obj = new Gson().fromJson(
												profile.toString(),
												CommonResponse.class);

										activity.onRequestSuccess(obj);
									} catch (Exception e) {
										activity.onRequestFailure(null);
										e.printStackTrace();
									}

								} else {
									// activity.onRequestFailure(status.getCode()
									// + "");
								}

							}

						});
	}

	//
	// public void BusinessDetailsResponse(String url, AQuery aq,
	// final BaseActivity activity, Map<String, Object> params) {
	//
	// GsonTransformer t = new GsonTransformer();
	// System.out.println("Url:" + url);
	//
	// for (Map.Entry<String, Object> entry : params.entrySet()) {
	// System.out.println(entry.getKey() + ":" + entry.getValue());
	// }
	// aq.transformer(t)
	// .progress(
	// DialogManager.getProgressDialog(activity,
	// R.string.please_wait))
	// .ajax(url, params, JSONObject.class,
	// new AjaxCallback<JSONObject>() {
	// public void callback(String url,
	// JSONObject profile, AjaxStatus status) {
	//
	// if (profile != null) {
	//
	// try {
	// Object obj = new Gson().fromJson(
	// profile.toString(),
	// BusinessDetails.class);
	//
	// activity.onRequestSuccess(obj);
	// } catch (Exception e) {
	// activity.onRequestFailure(null);
	// e.printStackTrace();
	// }
	//
	// } else {
	// activity.onRequestFailure(status.getCode()
	// + "");
	// }
	//
	// }
	//
	// });
	// }

	public void getLogin(String url, AQuery aq, final BaseActivity activity,
			Map<String, Object> params) {

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq.transformer(t)
		// .progress(DialogManager.LoadingDialog(activity))
				.ajax(url, params, JSONObject.class,
						new AjaxCallback<JSONObject>() {
							public void callback(String url,
									JSONObject profile, AjaxStatus status) {

								if (profile != null) {

									try {
										Object obj = new Gson().fromJson(
												profile.toString(), Login.class);

										activity.onRequestSuccess(obj);
									} catch (Exception e) {
										// activity.onRequestFailure(null);
										e.printStackTrace();
									}

								} else {
									activity.onRequestFailure(status.getCode()
											+ "");
								}

							}

						});
	}

	public void getMyOrder(String url, AQuery aq, final BaseFragment activity,
			Map<String, Object> params) {

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq.transformer(t)
		// .progress(DialogManager.LoadingDialog(activity.getActivity()))
				.ajax(url, params, JSONObject.class,
						new AjaxCallback<JSONObject>() {
							public void callback(String url,
									JSONObject profile, AjaxStatus status) {

								if (profile != null) {

									try {
										Object obj = new Gson().fromJson(
												profile.toString(),
												MyOrderRespose.class);

										activity.onRequestSuccess(obj);
									} catch (Exception e) {
										activity.onRequestFailure(null);
										e.printStackTrace();
									}

								} else {
									// activity.onRequestFailure(status.getCode()
									// + "");
								}

							}

						});
	}

	public void getReviews(String url, AQuery aq, final BaseFragment activity,
			Map<String, Object> params) {

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq.transformer(t)
		// .progress(DialogManager.LoadingDialog(activity.getActivity()))
				.ajax(url, params, JSONObject.class,
						new AjaxCallback<JSONObject>() {
							public void callback(String url,
									JSONObject profile, AjaxStatus status) {

								if (profile != null) {

									try {
										Object obj = new Gson().fromJson(
												profile.toString(),
												ReviewsResponse.class);

										activity.onRequestSuccess(obj);
									} catch (Exception e) {
										activity.onRequestFailure(null);
										e.printStackTrace();
									}

								} else {
									// activity.onRequestFailure(status.getCode()
									// + "");
								}

							}

						});
	}

	public void getProfile(String url, AQuery aq, final BaseFragment activity,
			Map<String, Object> params) {

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq.transformer(t)
		// .progress(DialogManager.LoadingDialog(activity.getActivity()))
				.ajax(url, params, JSONObject.class,
						new AjaxCallback<JSONObject>() {
							public void callback(String url,
									JSONObject profile, AjaxStatus status) {

								if (profile != null) {

									try {
										Object obj = new Gson().fromJson(
												profile.toString(),
												ProfileResponse.class);

										activity.onRequestSuccess(obj);
									} catch (Exception e) {
										activity.onRequestFailure(null);
										e.printStackTrace();
									}

								} else {
									// activity.onRequestFailure(status.getCode()
									// + "");
								}

							}

						});
	}

	public void callMapService(String url, AQuery aq,
			final BaseFragment activity, Map<String, Object> params) {

		GsonTransformer t = new GsonTransformer();
		System.out.println("Url:" + url);

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		aq.transformer(t)
		// .progress(DialogManager.LoadingDialog(activity.getActivity()))
				.ajax(url, params, JSONObject.class,
						new AjaxCallback<JSONObject>() {
							public void callback(String url,
									JSONObject profile, AjaxStatus status) {

								if (profile != null) {

									try {
										Object obj = new Gson().fromJson(
												profile.toString(),
												MapResponse.class);

										activity.onRequestSuccess(obj);
									} catch (Exception e) {
										activity.onRequestFailure(null);
										e.printStackTrace();
									}

								} else {
									// activity.onRequestFailure(status.getCode()
									// + "");
								}

							}

						});
	}
}
