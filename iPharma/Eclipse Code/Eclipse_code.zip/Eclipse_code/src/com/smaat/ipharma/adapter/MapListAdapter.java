package com.smaat.ipharma.adapter;

import java.text.DecimalFormat;
import java.util.ArrayList;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.androidquery.AQuery;
import com.smaat.ipharma.R;
import com.smaat.ipharma.entity.FavouriteCommonResponse;
import com.smaat.ipharma.entity.MapPropertyEntity;
import com.smaat.ipharma.entity.RateResponseEntity;
import com.smaat.ipharma.entity.WriteReviewEntity;
import com.smaat.ipharma.fragment.FavoriteFragment;
import com.smaat.ipharma.fragment.OrderNowFragment;
import com.smaat.ipharma.fragment.ReviewsFragment;
import com.smaat.ipharma.ui.HomeScreen;
import com.smaat.ipharma.util.AppConstants;
import com.smaat.ipharma.util.DialogManager;
import com.smaat.ipharma.util.DialogMangerCallback;
import com.smaat.ipharma.util.GlobalMethods;
import com.smaat.ipharma.util.RoundEdgeImageView;
import com.smaat.ipharma.webservice.APIRequestHandler;
import com.smaat.ipharma.webservice.UserInterfaceAPI;

public class MapListAdapter extends BaseAdapter implements OnClickListener,
		DialogMangerCallback {
	private Context context;
	private ArrayList<MapPropertyEntity> mPharmacyDetails;
	public static Dialog mDialog;
	public static String mShopId, mUserID;
	public static int mSelectPos;
	public holder mholder;

	public MapListAdapter(Context context,
			ArrayList<MapPropertyEntity> mPharmacyList) {
		// TODO Auto-generated constructor stub
		this.context = context;
		this.mPharmacyDetails = mPharmacyList;
		mUserID = ((String) GlobalMethods.getValueFromPreference(context,
				GlobalMethods.STRING_PREFERENCE, AppConstants.USER_ID));
	}

	public static class holder {
		TextView pharmacy_name, pharmacy_address, pharmacy_distance,
				pharmacy_review, min_order, delivery_time;
		RatingBar review_rating;
		ImageView pharmacy_premium;
		RoundEdgeImageView pharmacy_image_mask;
		RelativeLayout mViewLay;
		LinearLayout pharmacy_rat, pharmacy_revs;
		Bundle bundle;
	}

	public View getView(int position, View convertView, ViewGroup parent) {

		LayoutInflater inflater = ((Activity) context).getLayoutInflater();
		convertView = inflater.inflate(R.layout.list_item_pharmacy, null, true);

		mholder = new holder();

		mholder.mViewLay = (RelativeLayout) convertView
				.findViewById(R.id.view_lay);
		mholder.pharmacy_rat = (LinearLayout) convertView
				.findViewById(R.id.pharmacy_rat);
		mholder.pharmacy_revs = (LinearLayout) convertView
				.findViewById(R.id.pharmacy_revs);
		mholder.pharmacy_revs.setTag(position);
		mholder.mViewLay.setTag(position);
		mholder.pharmacy_name = (TextView) convertView
				.findViewById(R.id.pharmacy_name);
		mholder.pharmacy_name.setTypeface(HomeScreen.mHelveticaNormal);
		mholder.pharmacy_address = (TextView) convertView
				.findViewById(R.id.pharmacy_address);
		mholder.pharmacy_address.setTypeface(HomeScreen.mHelveticaNormal);
		mholder.pharmacy_distance = (TextView) convertView
				.findViewById(R.id.pharmacy_distance);
		mholder.pharmacy_distance.setTypeface(HomeScreen.mHelveticaNormal);
		mholder.pharmacy_review = (TextView) convertView
				.findViewById(R.id.pharmacy_review_count);
		mholder.pharmacy_review.setTypeface(HomeScreen.mHelveticaNormal);
		mholder.min_order = (TextView) convertView.findViewById(R.id.min_order);
		mholder.min_order.setTypeface(HomeScreen.mHelveticaNormal);
		mholder.delivery_time = (TextView) convertView
				.findViewById(R.id.delivery_time);
		mholder.delivery_time.setTypeface(HomeScreen.mHelveticaNormal);
		mholder.review_rating = (RatingBar) convertView
				.findViewById(R.id.pharmacy_rating);

		mholder.pharmacy_rat.setTag(position);
		mholder.pharmacy_premium = (ImageView) convertView
				.findViewById(R.id.pharmacy_fav);
		mholder.pharmacy_image_mask = (RoundEdgeImageView) convertView
				.findViewById(R.id.pharmacy_image_mask);
		// convertView.setTag(mholder);
		// }
		// final holder mholder = (holder) convertView.getTag();

		if (mPharmacyDetails.get(position).getIsPremium() != null
				&& mPharmacyDetails.get(position).getIsPremium()
						.equalsIgnoreCase(AppConstants.SUCCESS_CODE)) {
			mholder.pharmacy_premium.setVisibility(View.VISIBLE);
		} else {
			mholder.pharmacy_premium.setVisibility(View.GONE);
		}
		mholder.pharmacy_name.setText(mPharmacyDetails.get(position)
				.getShopName());
		mholder.pharmacy_address.setText(mPharmacyDetails.get(position)
				.getAddress());

		if (mPharmacyDetails.get(position).getDistance().contains(".")) {
			DecimalFormat distance_roundoff = new DecimalFormat("#.##");
			mholder.pharmacy_distance.setText(Double.valueOf(distance_roundoff
					.format(Double.valueOf(mPharmacyDetails.get(position)
							.getDistance())))
					+ " " + context.getString(R.string.km_away));
		} else {
			mholder.pharmacy_distance.setText(mPharmacyDetails.get(position)
					.getDistance() + " " + context.getString(R.string.km_away));
		}
		AQuery aq1 = new AQuery(context).recycle(convertView);

		aq1.id(mholder.pharmacy_image_mask)
				.progress(R.id.progress)
				.image("http://smaatapps.com/iPharma/admin/"
						+ mPharmacyDetails.get(position).getShopIcon(), true,
						true, 0, R.drawable.ipharma_message_icon, null, 0, 1.0f);
		mholder.min_order.setText(context.getString(R.string.min_order_rs)
				+ " " + mPharmacyDetails.get(position).getMinimumOrderValue());
		mholder.delivery_time.setText(context.getString(R.string.deliver_time)
				+ " " + mPharmacyDetails.get(position).getDeliveryTime() + " "
				+ context.getString(R.string.min));
		mholder.review_rating.setRating(Float.valueOf(mPharmacyDetails.get(
				position).getAvgRating()));
		mholder.pharmacy_review.setText(mPharmacyDetails.get(position)
				.getTotalReviews());
		mholder.pharmacy_rat.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int pos = Integer.parseInt(String.valueOf(v.getTag()));
				mSelectPos = pos;
				mShopId = mPharmacyDetails.get(pos).getPharmacyID();
				showRateDialog();
			}
		});
		mholder.pharmacy_revs.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int pos = Integer.parseInt(String.valueOf(v.getTag()));
				mShopId = mPharmacyDetails.get(pos).getPharmacyID();
				AppConstants.Pharmacy_id = mShopId;
				AppConstants.from_map_list_review = AppConstants.SUCCESS_CODE;
				((HomeScreen) context).replaceFragment(new ReviewsFragment(),
						true);
				HomeScreen.mHeaderLeft
						.setBackgroundResource(R.drawable.back_butto);
				HomeScreen.mBottombar.setVisibility(View.GONE);
				HomeScreen.mFooterText.setText(R.string.write_review);
				HomeScreen.mHeaderRight.setVisibility(View.INVISIBLE);
			}
		});

		mholder.mViewLay.setOnClickListener(new OnClickListener() {

			@SuppressWarnings("static-access")
			@Override
			public void onClick(View v) {
				int pos = Integer.parseInt(String.valueOf(v.getTag()));
				((HomeScreen) context).mFragment = new OrderNowFragment();
				mholder.bundle = new Bundle();

				AppConstants.FROM_MAPFAVORITE_SCREEN = AppConstants.MAP_SCREEN;
				mholder.bundle.putSerializable("pharmcay_details",
						mPharmacyDetails.get(pos));
				((HomeScreen) context).mFragment.setArguments(mholder.bundle);
				((HomeScreen) context).replaceFragment(
						((HomeScreen) context).mFragment, true);
				HomeScreen.mHeaderRightLay.setVisibility(View.INVISIBLE);
				HomeScreen.mHeaderLeft
						.setBackgroundResource(R.drawable.back_butto);
			}
		});
		//
		// MapListFragment.mAll.setText("All " + "(" +
		// mPharmacyDetails.size()
		// + ")");
		// MapListFragment.mPreminum.setText("Premium " + "("
		// + holder.premium_count + ")");
		// MapListFragment.mNormal.setText("Normal " + "(" +
		// holder.normal_count
		// + ")");

		return convertView;
	}

	public void showRateDialog() {

		mDialog = new Dialog(context);
		mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mDialog.setContentView(R.layout.dialog_rate);

		mDialog.getWindow().setBackgroundDrawable(
				new ColorDrawable(Color.TRANSPARENT));
		WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
		wmlp.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;

		mDialog.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
						| WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		Button rate = (Button) mDialog.findViewById(R.id.rate_it);
		Button cancel = (Button) mDialog.findViewById(R.id.cancel);
		rate.setTypeface(HomeScreen.mHelveticaBold);
		cancel.setTypeface(HomeScreen.mHelveticaBold);
		TextView mRateText = (TextView) mDialog.findViewById(R.id.rate_text);
		final TextView mRating_avg_txt = (TextView) mDialog
				.findViewById(R.id.rating_avg_txt);
		mRating_avg_txt.setTypeface(HomeScreen.mHelveticaBold);
		mRateText.setTypeface(HomeScreen.mHelveticaNormal);
		final RatingBar mFav_ratingbar = (RatingBar) mDialog
				.findViewById(R.id.fav_ratingbar);
		final Button mRating_icons = (Button) mDialog
				.findViewById(R.id.rating_icons);

		mFav_ratingbar
				.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {

					public void onRatingChanged(RatingBar ratingBar,
							float rating, boolean fromUser) {
						switch ((int) mFav_ratingbar.getRating()) {
						case 1:
							mRating_avg_txt.setText(context
									.getString(R.string.poor));
							mRating_icons
									.setBackgroundResource(R.drawable.poor);
							break;
						case 2:
							mRating_avg_txt.setText(context
									.getString(R.string.bad));
							mRating_icons.setBackgroundResource(R.drawable.bad);
							break;
						case 3:
							mRating_avg_txt.setText(context
									.getString(R.string.average));
							mRating_icons
									.setBackgroundResource(R.drawable.average);
							break;
						case 4:
							mRating_avg_txt.setText(context
									.getString(R.string.good));
							mRating_icons
									.setBackgroundResource(R.drawable.good);
							break;
						case 5:
							mRating_avg_txt.setText(context
									.getString(R.string.excellent));
							mRating_icons
									.setBackgroundResource(R.drawable.excellent);
							break;
						}
					}
				});
		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mDialog.dismiss();
			}
		});
		rate.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				float rating_value = mFav_ratingbar.getRating();
				callPharmacyRatingService(rating_value);
				mDialog.dismiss();
			}
		});

		mDialog.show();
	}

	private void callPharmacyRatingService(float rating_value) {

		// String rating = String.valueOf(rating_value);
		// APIRequestHandler.getInstance().shopRating(mShopId,
		// GlobalMethods.getUserID(), rating, this);
		DialogManager.showProgress(context);
		RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(
				AppConstants.Base_Url).build();
		UserInterfaceAPI interfaces = restAdapter
				.create(UserInterfaceAPI.class);

		String rating = String.valueOf(rating_value);

		// String UserID = GlobalMethods.getUserID(context);
		interfaces.shopRating(mShopId, mUserID, rating,
				new Callback<RateResponseEntity>() {

					public void failure(RetrofitError arg0) {

						DialogManager.hideProgress(context);
						DialogManager.showCustomAlertDialog(context,
								MapListAdapter.this,
								context.getString(R.string.no_network));
					}

					public void success(RateResponseEntity mRatingResponse,
							Response obj) {

						if (mRatingResponse.getStatus().equalsIgnoreCase(
								"success")) {

							DialogManager.hideProgress(context);
							DialogManager.showCustomAlertDialog(context,
									MapListAdapter.this,
									context.getString(R.string.rating_added));
							mPharmacyDetails.get(mSelectPos).setAvgRating(
									mRatingResponse.getResult());
							notifyDataSetChanged();
							// mMapProperties.get(mSelectPos).setAvgRating(
							// String.valueOf(response.getResult()));
							// setAdapter(mMapProperties);
							// mholder.review_rating.setRating(Float
							// .valueOf(response.getResult()));
						}
					}

				});
	}

	// private void setListAdapter() {
	// premium_count = 0;
	// normal_count = 0;
	// for (int i = 0; i < mPharmacyList.size(); i++) {
	// if (mPharmacyList.get(i).getIsPremium() != null
	// && mPharmacyList.get(i).getIsPremium()
	// .equalsIgnoreCase("1")) {
	// premium_count = premium_count + 1;
	// } else {
	// normal_count = normal_count + 1;
	// }
	// LayoutInflater mInflater = (LayoutInflater) getActivity()
	// .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	// View view = mInflater.inflate(R.layout.list_item_pharmacy, null);
	// Typeface mTypeface = TypefaceSingleton.getInstance().getHelvetica(
	// getActivity());
	// RelativeLayout mViewLay = (RelativeLayout) view
	// .findViewById(R.id.view_lay);
	// mViewLay.setTag(i);
	//
	// pharmacy_name = (TextView) view.findViewById(R.id.pharmacy_name);
	// pharmacy_name.setTypeface(mTypeface);
	// pharmacy_address = (TextView) view
	// .findViewById(R.id.pharmacy_address);
	// pharmacy_address.setTypeface(mTypeface);
	// pharmacy_distance = (TextView) view
	// .findViewById(R.id.pharmacy_distance);
	// pharmacy_distance.setTypeface(mTypeface);
	// pharmacy_review = (TextView) view
	// .findViewById(R.id.pharmacy_review_count);
	// pharmacy_review.setTypeface(mTypeface);
	// min_order = (TextView) view.findViewById(R.id.min_order);
	// min_order.setTypeface(mTypeface);
	// delivery_time = (TextView) view.findViewById(R.id.delivery_time);
	// delivery_time.setTypeface(mTypeface);
	// review_rating = (RatingBar) view.findViewById(R.id.pharmacy_rating);
	// ImageView pharmacy_premium = (ImageView) view
	// .findViewById(R.id.pharmacy_fav);
	// if (mPharmacyList.get(i).getIsPremium() != null
	// && mPharmacyList.get(i).getIsPremium()
	// .equalsIgnoreCase("1")) {
	// pharmacy_premium.setVisibility(View.VISIBLE);
	// } else {
	// pharmacy_premium.setVisibility(View.GONE);
	// }
	//
	// pharmacy_name.setText(mPharmacyList.get(i).getShopName());
	// pharmacy_address.setText(mPharmacyList.get(i).getAddress());
	// if (mPharmacyList.get(i).getDistance().contains(".")) {
	// DecimalFormat distance_roundoff = new DecimalFormat("#.##");
	// pharmacy_distance.setText(Double.valueOf(distance_roundoff
	// .format(Double.valueOf(mPharmacyList.get(i)
	// .getDistance())))
	// + " km Away");
	// } else {
	// pharmacy_distance.setText(mPharmacyList.get(i).getDistance()
	// + " km Away");
	// }
	//
	// min_order.setText("Min Order - Rs "
	// + mPharmacyList.get(i).getMinimumOrderValue());
	// delivery_time.setText("Delivery Time - "
	// + mPharmacyList.get(i).getDeliveryTime() + " min");
	// review_rating.setRating(Float.valueOf(mPharmacyList.get(i)
	// .getAvgRating()));
	// pharmacy_review.setText(mPharmacyList.get(i).getTotalReviews());
	//
	// mViewLay.setOnClickListener(new OnClickListener() {
	//
	// public void onClick(View v) {
	// int pos = Integer.parseInt(String.valueOf(v.getTag()));
	// ((HomeScreen) getActivity()).mFragment = new OrderNowFragment();
	// bundle = new Bundle();
	// bundle.putSerializable("pharmcay_details",
	// mPharmacyList.get(pos));
	// ((HomeScreen) getActivity()).mFragment.setArguments(bundle);
	// ((HomeScreen) getActivity())
	// .replaceFragment(((HomeScreen) getActivity()).mFragment);
	// HomeScreen.mHeaderRight.setVisibility(View.INVISIBLE);
	// HomeScreen.mHeaderLeft
	// .setBackgroundResource(R.drawable.order_now_back_btn);
	// HomeScreen.mHeaderText.setText(R.string.order_now);
	// }
	// });
	//
	// mMapListView.addView(view);
	//
	// }
	//
	// mAll.setText("All " + "(" + mPharmacyList.size() + ")");
	// mPreminum.setText("Premium " + "(" + premium_count + ")");
	// mNormal.setText("Normal " + "(" + normal_count + ")");
	// }
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mPharmacyDetails.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onItemclick(String SelctedItem, int pos) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onOkclick() {
		// TODO Auto-generated method stub

	}

}
