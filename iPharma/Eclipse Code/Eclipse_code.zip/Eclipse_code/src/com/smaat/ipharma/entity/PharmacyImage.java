package com.smaat.ipharma.entity;

public class PharmacyImage {
	private byte[] pharmacy1;
	private byte[] pharmacy2;
	private byte[] pharmacy3;

	public byte[] getPharmacy1() {
		return pharmacy1;
	}

	public void setPharmacy1(byte[] pharmacy1) {
		this.pharmacy1 = pharmacy1;
	}

	public byte[] getPharmacy2() {
		return pharmacy2;
	}

	public void setPharmacy2(byte[] pharmacy2) {
		this.pharmacy2 = pharmacy2;
	}

	public byte[] getPharmacy3() {
		return pharmacy3;
	}

	public void setPharmacy3(byte[] pharmacy3) {
		this.pharmacy3 = pharmacy3;
	}

}
