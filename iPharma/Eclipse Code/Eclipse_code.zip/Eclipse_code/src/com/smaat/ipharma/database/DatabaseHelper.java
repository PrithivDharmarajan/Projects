package com.smaat.ipharma.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

	private static final int DATABASE_VERSION = 1;
	private static final String DATABASE_NAME = "appdetail.sqlite";

	public static final String TABLE_MYPROFILE = "myapp";

	public static final String KEY_OWNER = "owner_name";
	public static final String KEY_EMAIL = "email";
	public static final String KEY_PHARMA_NAME = "pharma_name";
	public static final String KEY_ADDRESS = "addresss";
	public static final String KEY_PHONE = "phone";

	public static final String KEY_WEBSITE = "website";
	public static final String KEY_OPEN_TIME = "open_time";
	public static final String KEY_CLOSE_TIME = "close_time";
	public static final String KEY_DELIVER_TIME = "delivery_time";
	public static final String KEY_MIN_PURCHASE = "mini_pur";
	public static final String KEY_IS_NEW = "new_one";
	public static final String KEY_LAT = "lat";
	public static final String KEY_LONG = "long";
	public static final String KEY_PHOTO1 = "photo1";
	public static final String KEY_PHOTO2 = "photo2";
	public static final String KEY_PHOTO3 = "photo3";
	public static final String KEY_PHOTO4 = "photo4";
	public static final String KEY_DATE = "date";
	public static final String KEY_IS_DELIVERY = "isdelivery";
	public static final String KEY_USERID = "userid";
	public static final String KEY_ROW_ID = "rowid";

	public DatabaseHelper(Context context) {

		super(context, DATABASE_NAME, null, DATABASE_VERSION);

	}

	@Override
	public void onCreate(SQLiteDatabase db) {

		db.execSQL("CREATE TABLE " + TABLE_MYPROFILE + "(" + KEY_PHONE
				+ " TEXT NOT NULL, " + KEY_PHARMA_NAME + " TEXT NOT NULL, "
				+ KEY_ADDRESS + " TEXT NOT NULL, " + KEY_OWNER
				+ " TEXT NOT NULL, " + KEY_EMAIL + " TEXT NOT NULL, "
				+ KEY_WEBSITE + " TEXT NOT NULL, " + KEY_OPEN_TIME
				+ " TEXT NOT NULL, " + KEY_CLOSE_TIME + " TEXT NOT NULL, "
				+ KEY_DELIVER_TIME + " TEXT NOT NULL, " + KEY_MIN_PURCHASE
				+ " TEXT NOT NULL, " + KEY_LAT + " TEXT NOT NULL, " + KEY_LONG
				+ " TEXT NOT NULL, " + KEY_PHOTO1 + " BLOB, " + KEY_PHOTO2
				+ " BLOB, " + KEY_PHOTO3 + " BLOB, " + KEY_PHOTO4 + " BLOB, "
				+ KEY_DATE + " TEXT NOT NULL, " + KEY_IS_NEW
				+ " TEXT NOT NULL, " + KEY_ROW_ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_IS_DELIVERY
				+ " TEXT NOT NULL" + ");");

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

	}

}
