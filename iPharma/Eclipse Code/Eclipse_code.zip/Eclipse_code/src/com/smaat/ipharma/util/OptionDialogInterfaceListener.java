package com.smaat.ipharma.util;

public interface OptionDialogInterfaceListener {
	public void okClick();

	public void cancelClick();
}
