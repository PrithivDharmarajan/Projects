package com.smaat.ipharma;

import java.util.Random;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;

import com.smaat.ipharma.fragment.MyOrderFragment;
import com.smaat.ipharma.ui.GCMTempScreen;
import com.smaat.ipharma.ui.HomeScreen;
import com.smaat.ipharma.util.AppConstants;
import com.smaat.ipharma.util.GlobalMethods;

public class GCMReceiver extends WakefulBroadcastReceiver {
	private static final String TAG = "GCMIntentService";
	private JSONObject json;
	private static String mMessage = "", mTypeId = "",mPurpose="";

	@Override
	public void onReceive(Context context, Intent intent) {
		String regId = intent.getExtras().getString("registration_id");
		if (regId != null && !regId.equals("")) {
			System.out.println("DEVICEID: " + regId);
			GlobalMethods.storeValuetoPreference(context,
					GlobalMethods.STRING_PREFERENCE,
					AppConstants.pref_deviceReg_Id, regId);

			GlobalMethods.storeValuetoPreference(context,
					GlobalMethods.BOOLEAN_PREFERENCE,
					AppConstants.pref_device_reg_status, false);

			GlobalMethods
					.storeValuetoPreference(context,
							GlobalMethods.BOOLEAN_PREFERENCE,
							AppConstants.pref_device_id_changed,
							AppConstants.pref_deviceReg_Id
									.equalsIgnoreCase(regId) ? false : true);
		}
		Log.i(TAG, "Received message");
		mMessage = "";
		// String intentStr = intent.getExtras().getString(
		// context.getString(R.string.message));
		// if (intentStr != null) {
		// try {
		// json = new JSONObject(intentStr);
		// mMessage = json.getString("msg");
		// mTypeId = json.getString("type");
		// // info = json.getString(context.getString(R.string.info));
		// } catch (JSONException e) {
		// e.printStackTrace();
		// }
		//
		// }
		
		mMessage = intent.getExtras().getString("msg");
		 mTypeId = intent.getExtras().getString("type");
		 mPurpose = intent.getExtras().getString("purpose");

		if (mMessage != null && !mMessage.equalsIgnoreCase("")) {
			// if (JOLTApplication.isActivityVisible()) {
			// HomeScreen.displayNotifyDialog(message, type,info);
			// } else {
			generateNotification(context, mMessage);
			// }
			mMessage = "";
		}
	}

	@SuppressWarnings("deprecation")
	private static void generateNotification(Context context, String message) {
		Random r = new Random();
		int notifiId = r.nextInt();
		int icon = R.drawable.app_icon;
		long when = System.currentTimeMillis();
		NotificationManager notificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		Notification notification = new Notification(icon, message, when);
		String title = context.getString(R.string.app_name);

		Intent notificationIntent = new Intent(context, GCMTempScreen.class);
		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
				| Intent.FLAG_ACTIVITY_SINGLE_TOP
				| Intent.FLAG_ACTIVITY_NEW_TASK);
		notificationIntent.putExtra("type", mTypeId);

		PendingIntent intent = PendingIntent.getActivity(context,
				"".hashCode(), notificationIntent,Intent.FLAG_ACTIVITY_CLEAR_TOP
				|Intent.FLAG_ACTIVITY_NEW_TASK);
		notification.setLatestEventInfo(context, title, message, intent);
		notification.flags |= Notification.FLAG_AUTO_CANCEL;
		notification.defaults |= Notification.DEFAULT_SOUND;
		notification.defaults |= Notification.DEFAULT_VIBRATE;
		notificationManager.notify(notifiId, notification);
		
//		int icon = R.drawable.ic_launcher;
//		long when = System.currentTimeMillis();
//		NotificationManager notificationManager = (NotificationManager) context
//				.getSystemService(Context.NOTIFICATION_SERVICE);
//		Notification notification = new Notification(icon, message, when);
//
//		String title = context.getString(R.string.app_name);
//
//		Intent notificationIntent = new Intent(context, HomeScreen.class);
//		// set intent so it does not start a new activity
//		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
//				| Intent.FLAG_ACTIVITY_SINGLE_TOP);
//		PendingIntent intent = PendingIntent.getActivity(context, 0,
//				notificationIntent, 0);
//		notification.setLatestEventInfo(context, title, message, intent);
//		notification.flags |= Notification.FLAG_AUTO_CANCEL;
//
//		// Play default notification sound
//		notification.defaults |= Notification.DEFAULT_SOUND;
//
//		// Vibrate if vibrate is enabled
//		notification.defaults |= Notification.DEFAULT_VIBRATE;
//		notificationManager.notify(0, notification);
	}
}
