package com.smaat.ipharma.fragment;

import java.util.ArrayList;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.renderscript.Sampler.Value;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import com.androidquery.AQuery;
import com.smaat.ipharma.BaseFragment;
import com.smaat.ipharma.R;
import com.smaat.ipharma.entity.HistoryOrderEntity;
import com.smaat.ipharma.entity.OrderHistoryCommonResponseEntity;
import com.smaat.ipharma.model.MyOrderRespose;
import com.smaat.ipharma.ui.HomeScreen;
import com.smaat.ipharma.util.AppConstants;
import com.smaat.ipharma.util.DialogManager;
import com.smaat.ipharma.util.DialogMangerCallback;
import com.smaat.ipharma.util.GlobalMethods;
import com.smaat.ipharma.util.RoundEdgeImageView;
import com.smaat.ipharma.util.TypefaceSingleton;
import com.smaat.ipharma.webservice.UserInterfaceAPI;

public class MyOrderFragment extends BaseFragment implements
		DialogMangerCallback {
	private TableLayout mFavTable;
	private RoundEdgeImageView pharmacyImage;
	private TextView pharmacyName, mStatus, pharmacyAddress, mOrderedDate,
			mOrderedId, mExpectDate;
	// private ArrayList<MyOrder> mOrderEntity;
	private String UserID, mTempPayPrice;
	private AQuery aq1;
	private RelativeLayout mOrder_main_lay;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootview = inflater.inflate(R.layout.fragment_favourite,
				container, false);
		setupUI(rootview);
		return rootview;
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		ViewGroup mViewGroup = (ViewGroup) view
				.findViewById(R.id.parent_layout);
		Typeface mTypeface = TypefaceSingleton.getInstance().getHelvetica(
				getActivity());
		setFont(mViewGroup, mTypeface);
		setupUI(mViewGroup);
		hideSoftKeyboard(getActivity());
		AppConstants.FRAG = AppConstants.MAP_SCREEN;
		HomeScreen.mHeaderRightLay.setVisibility(View.INVISIBLE);
		UserID = GlobalMethods.getUserID(getActivity());
		HomeScreen.mHeaderLeftLay.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {

				HomeScreen.onBackMove(getActivity());
			}
		});
		initComponents(view);
		callOrderHistoryService(); // API CAll

	}

	private void callOrderHistoryService() {
		DialogManager.showProgress(getActivity());
		RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(
				AppConstants.Base_Url).build();
		UserInterfaceAPI interfaces = restAdapter
				.create(UserInterfaceAPI.class);

		interfaces.getMyOrders(UserID,
				new Callback<OrderHistoryCommonResponseEntity>() {

					public void failure(RetrofitError arg0) {
						DialogManager.hideProgress(getActivity());
						DialogManager.showCustomAlertDialog(getActivity(),
								MyOrderFragment.this,
								getString(R.string.no_network));
					}

					public void success(
							OrderHistoryCommonResponseEntity response,
							Response obj) {
						DialogManager.hideProgress(getActivity());
						if (response.getStatus().equalsIgnoreCase(
								AppConstants.SUCCESS_CODE)) {
							setAdapter(response.getResult().getOrderResult());

						} else {
							DialogManager.hideProgress(getActivity());

						}
					}

				});
	}

	private void initComponents(View view) {

		mFavTable = (TableLayout) view.findViewById(R.id.favourite_table);
	}

	public void setAdapter(final ArrayList<HistoryOrderEntity> orderList) {
		if (orderList != null) {
			for (int i = 0; i < orderList.size(); i++) {
				LayoutInflater inflater = (LayoutInflater) getActivity()
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

				View view = inflater.inflate(R.layout.myorder_item, null);

				pharmacyImage = (RoundEdgeImageView) view
						.findViewById(R.id.pharmacy_image_mask);
				mOrder_main_lay = (RelativeLayout) view
						.findViewById(R.id.order_main_lay);
				mOrder_main_lay.setTag(i);

				aq1 = new AQuery(getActivity()).recycle(view);

				aq1.id(pharmacyImage)
						.progress(R.id.progress)
						.image(AppConstants.Base_Url + "/"
								+
								orderList.get(i).getPrescriptionURL(), true, true,
								0, R.drawable.ipharma_message_icon, null, 0,
								1.0f);
				// Picasso.with(getActivity())
				// .load("http://smaatapps.com/iPharma/admin/"
				// + orderList.get(i).getShopIcon())
				// .placeholder(
				// getActivity().getResources().getDrawable(
				// R.drawable.ipharma_message_icon))
				// .error(getActivity().getResources().getDrawable(
				// R.drawable.ipharma_message_icon)).into(pharmacyImage);
				pharmacyName = (TextView) view.findViewById(R.id.pharmacy_name);
				pharmacyAddress = (TextView) view
						.findViewById(R.id.pharmacy_address);
				mOrderedDate = (TextView) view.findViewById(R.id.ordered_date);
				mOrderedId = (TextView) view.findViewById(R.id.ordered_id);
				mStatus = (TextView) view.findViewById(R.id.status);
				mExpectDate = (TextView) view.findViewById(R.id.expect_date);

				pharmacyName.setTypeface(HomeScreen.mHelveticaBold);
				// pharmacyAddress.setTypeface(HomeScreen.mHelveticaNormal);
				// mOrderedDate.setTypeface(HomeScreen.mHelveticaNormal);
				// mOrderedId.setTypeface(HomeScreen.mHelveticaNormal);
				// mStatus.setTypeface(HomeScreen.mHelveticaNormal);
				// mExpectDate.setTypeface(HomeScreen.mHelveticaNormal);

				String deliver_status = "";
				switch (Integer.parseInt(orderList.get(i).getOrderStatus())) {
				case 0:
					deliver_status = getString(R.string.in_progress);
					mExpectDate.setText("");
					// mExpectDate.setText(getString(R.string.expected_status)
					// + " " + orderList.get(i).getDeliveryTime() + " "
					// + getString(R.string.min));
					break;
				case 1:
					deliver_status = getString(R.string.action_required);
					mExpectDate.setText(getString(R.string.amnt_paid) + " "
							+ orderList.get(i).getOrderPrice());
					break;
				case -1:
					deliver_status = getString(R.string.reject);
					mExpectDate.setText("");
					break;
				case 2:
					deliver_status = getString(R.string.delivery_started);
					mExpectDate.setText(getString(R.string.expected_status)
							+ " " + orderList.get(i).getDeliveryTime() + " ");
					// + getString(R.string.min));
					break;
				case 3:
					deliver_status = getString(R.string.delivered);
					mExpectDate.setText("");
					break;
				case 4:
					deliver_status = getString(R.string.cancel_order);
					mExpectDate.setText("");
					break;
				case 5:
					deliver_status = getString(R.string.payment_over);
					mExpectDate.setText("");
					break;
				default:
					break;
				}

				mOrder_main_lay.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						int pos = Integer.parseInt(String.valueOf(v.getTag()));
						// orderList.get(i).getOrderPrice();
						// if (orderList.get(pos).getOrderStatus()
						// .equalsIgnoreCase(AppConstants.SUCCESS_CODE)) {
						AppConstants.from_my_order = AppConstants.SUCCESS_CODE;
						AppConstants.photo = AppConstants.PHOTO;
						HomeScreen.mHeaderRightLay
								.setVisibility(View.INVISIBLE);
						HomeScreen.mBottombar.setVisibility(View.GONE);
						HomeScreen.mFooterText.setText(R.string.place_order);
						if (orderList != null && orderList.size() != 0) {
							AppConstants.history_prec_img = orderList.get(pos)
									.getPrescriptionURL();
							AppConstants.history_mPharmacyName = orderList.get(
									pos).getShopName();
							AppConstants.history_mPharmacyAddress = orderList
									.get(pos).getAddress();
							AppConstants.history_mDistance = orderList.get(pos)
									.getDeliveryTime();
							AppConstants.history_mShopId = orderList.get(pos)
									.getShopID();
							AppConstants.history_mPrescriptionId = orderList
									.get(pos).getOrderID();
							AppConstants.history_mNotehere = orderList.get(pos)
									.getOrderNote();
							mTempPayPrice = orderList.get(pos).getOrderPrice();
							// if (mTempPayPrice == null
							// || mTempPayPrice.equals("")) {
							// mTempPayPrice = String.valueOf(100);
							// }

							if (Integer.parseInt(orderList.get(pos)
									.getOrderStatus()) == 0) {
								AppConstants.delivery_status = getString(R.string.status)
										+ " " + getString(R.string.in_progress);
							} else if (Integer.parseInt(orderList.get(pos)
									.getOrderStatus()) == 1) {
								AppConstants.delivery_status = getString(R.string.pay_rs)
										+ " " + mTempPayPrice;
								GlobalMethods.storeValuetoPreference(
										getActivity(),
										GlobalMethods.STRING_PREFERENCE,
										AppConstants.IPHARMA_MONEY,
										mTempPayPrice);

							} else if (Integer.parseInt(orderList.get(pos)
									.getOrderStatus()) == -1) {
								AppConstants.delivery_status = getString(R.string.status)
										+ " " + getString(R.string.reject);
							} else if (Integer.parseInt(orderList.get(pos)
									.getOrderStatus()) == 2) {
								// AppConstants.delivery_status =
								// getString(R.string.pay_rs)
								// + " " + mTempPayPrice;
								// GlobalMethods.storeValuetoPreference(
								// getActivity(),
								// GlobalMethods.STRING_PREFERENCE,
								// AppConstants.IPHARMA_MONEY,
								// mTempPayPrice);

							} else if (Integer.parseInt(orderList.get(pos)
									.getOrderStatus()) == 3) {
								AppConstants.delivery_status = getString(R.string.status)
										+ " " + getString(R.string.delivered);
							} else if (Integer.parseInt(orderList.get(pos)
									.getOrderStatus()) == 4) {
								AppConstants.delivery_status = getString(R.string.status)
										+ " "
										+ getString(R.string.cancel_order);
							} else if (Integer.parseInt(orderList.get(pos)
									.getOrderStatus()) == 5) {
								AppConstants.delivery_status = getString(R.string.status)
										+ " "
										+ getString(R.string.payment_over);
							}
							// AppConstants.delivery_status =
							// getString(R.string.pay_rs)
							// + " " + orderList.get(pos).getOrderPrice();
							AppConstants.purchase_amount = orderList.get(pos)
									.getOrderPrice();
						} else {
							AppConstants.history_mPharmacyName = "";
							AppConstants.history_mPharmacyAddress = "";
							AppConstants.history_mDistance = "";
							AppConstants.history_mShopId = "";
							AppConstants.history_mPrescriptionId = "";
							AppConstants.history_mNotehere = "";
						}

						((HomeScreen) getActivity()).replaceFragment(
								new OrderDetailsFragment(), true);
						// }
					}
				});

				pharmacyName.setText(orderList.get(i).getShopName());
				pharmacyAddress.setText(orderList.get(i).getAddress()
						+ orderList.get(i).getArea()
						+ orderList.get(i).getCity() + "-"
						+ orderList.get(i).getPincode());
				mOrderedDate.setText(getString(R.string.ordered_at)
						+ orderList.get(i).getOrderDateTime());
				mOrderedId.setText("Order Id" + " : "
						+ orderList.get(i).getOrderID());
				mStatus.setText(deliver_status);

				mFavTable.addView(view);

			}
		}
	}

	// public void getmyorderService() {
	//
	// HashMap<String, Object> params = new HashMap<String, Object>();
	// final String url = "";
	//
	// params.put("userid", "");
	//
	// ServieRequestHandler.getInstance().getMyOrder(url, aq(), this, params);
	// }

	@Override
	public void onRequestSuccess(Object responseObj) {
		super.onRequestSuccess(responseObj);

		if (responseObj != null) {
			MyOrderRespose order = (MyOrderRespose) responseObj;
			if (order.getError_code().equalsIgnoreCase(
					AppConstants.SUCCESS_CODE)) {
				// mOrderEntity = order.getResult();
				DialogManager.showPopUpDialog(getActivity(), this,
						order.getMsg());
			}
		}

	}

	// @Override
	// public void onDestroy() {
	// // TODO Auto-generated method stub
	// }

	public void onItemclick(String SelctedItem, int pos) {
		// TODO Auto-generated method stub

	}

	public void onOkclick() {
		// TODO Auto-generated method stub

	}

}
