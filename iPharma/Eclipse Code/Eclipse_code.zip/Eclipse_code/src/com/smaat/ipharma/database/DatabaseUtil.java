package com.smaat.ipharma.database;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.smaat.ipharma.R;
import com.smaat.ipharma.db.model.Image;
import com.smaat.ipharma.db.model.UserDetails;
import com.smaat.ipharma.util.DialogManager;

public class DatabaseUtil {

	private SQLiteDatabase db;
	DatabaseHelper dbhelper = null;

	public void open() throws SQLiteException {
		// dbhelper = new DatabaseHelper(context);
		// db = dbhelper.getWritableDatabase();
		db = DatabaseManager.getInstance().openDatabase();
	}

	@SuppressWarnings("unused")
	private Context context;

	public DatabaseUtil(Context context) {
		dbhelper = new DatabaseHelper(context);
		this.context = context;
	}

	public void close() {
		DatabaseManager.getInstance().closeDatabase();
	}

	public int myProfileInsert(Context context, String phone, String phar_name,
			String address, String ownernme, String email, String website,
			String opentime, String closetime, String deliverytime,
			String minipur, String isNew, double latitude, double longitude,
			byte[] photo1, byte[] photo2, byte[] photo3, byte[] photo4,
			String date, String isdelivery) {
		open();
		int count = 0;
		try {

			ContentValues values = new ContentValues();
			values.put(DatabaseHelper.KEY_PHONE, phone);
			values.put(DatabaseHelper.KEY_OWNER, ownernme);
			values.put(DatabaseHelper.KEY_ADDRESS, address);
			values.put(DatabaseHelper.KEY_EMAIL, email);
			values.put(DatabaseHelper.KEY_PHARMA_NAME, phar_name);
			values.put(DatabaseHelper.KEY_WEBSITE, website);
			values.put(DatabaseHelper.KEY_OPEN_TIME, opentime);
			values.put(DatabaseHelper.KEY_CLOSE_TIME, closetime);
			values.put(DatabaseHelper.KEY_DELIVER_TIME, deliverytime);
			values.put(DatabaseHelper.KEY_MIN_PURCHASE, minipur);
			values.put(DatabaseHelper.KEY_IS_NEW, isNew);
			values.put(DatabaseHelper.KEY_LAT, latitude);
			values.put(DatabaseHelper.KEY_LONG, longitude);
			values.put(DatabaseHelper.KEY_PHOTO1, photo1);
			values.put(DatabaseHelper.KEY_PHOTO2, photo2);
			values.put(DatabaseHelper.KEY_PHOTO3, photo3);
			values.put(DatabaseHelper.KEY_PHOTO4, photo4);
			values.put(DatabaseHelper.KEY_DATE, date);
			values.put(DatabaseHelper.KEY_IS_DELIVERY, isdelivery);

			try {
				count += ((db.insertWithOnConflict(
						DatabaseHelper.TABLE_MYPROFILE, null, values,
						SQLiteDatabase.CONFLICT_IGNORE)) == -1) ? 0 : 1;
				System.out.println(count);
				if (count > 0) {
					DialogManager.showMessageDialog(context,
							context.getString(R.string.saved_successfully), context.getString(R.string.ok));

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return count;

	}

	public ArrayList<UserDetails> getProfile() {
		ArrayList<UserDetails> userList = new ArrayList<UserDetails>();
		open();
		String query;

		query = "select * from " + DatabaseHelper.TABLE_MYPROFILE + " where "
				+ DatabaseHelper.KEY_IS_NEW + "='" + "0" + "'";
		Cursor cursor = db.rawQuery(query, null);
		try {
			if (cursor != null) {
				if (cursor.getCount() > 0) {
					cursor.moveToFirst();
					do {
						UserDetails user = new UserDetails();

						user.setPhone_number(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE)));

						user.setPharmacy_name(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHARMA_NAME)));

						user.setAddress(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_ADDRESS)));

						user.setOwner_name(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_OWNER)));

						user.setEmail_id(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_EMAIL)));
						user.setWebsite(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_WEBSITE)));
						user.setOpening_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_OPEN_TIME)));
						user.setClosing_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_CLOSE_TIME)));
						user.setDelivery_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_DELIVER_TIME)));
						user.setMin_purchase(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_MIN_PURCHASE)));
						user.setHome_delivery(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_IS_DELIVERY)));
						user.setDatetime(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_DATE)));
						user.setLatitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_LAT)));
						user.setLongitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_LONG)));
						user.setIsNew(cursor.getInt(cursor
								.getColumnIndex(DatabaseHelper.KEY_IS_NEW)));
						user.setRowid(cursor.getInt(cursor
								.getColumnIndex(DatabaseHelper.KEY_ROW_ID)));

						Image image = new Image();
						image.setImage1(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO1)));

						image.setImage2(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO2)));
						image.setImage3(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO3)));

						image.setImage4(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO4)));
						user.setImage(image);
						System.out.println("Image1:::" + image.getImage1()
								+ "Image2:::" + image.getImage2() + "Image3::"
								+ image.getImage3() + "Image4:::"
								+ image.getImage4());

						userList.add(user);
					} while (cursor.moveToNext());
				}
			}
		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
			e.printStackTrace();
		} finally {
			if (cursor != null)
				cursor.close();
			close();
		}
		return userList;
	}

	public void UpdateTable(int i) {
		try {

			ContentValues values = new ContentValues();

			values.put(DatabaseHelper.KEY_IS_NEW, "1");

			open();

			db.update(DatabaseHelper.TABLE_MYPROFILE, values,
					DatabaseHelper.KEY_IS_NEW + " = ?" + "AND "
							+ DatabaseHelper.KEY_ROW_ID + " = ?", new String[] {
							"0", String.valueOf(i) });

		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
		}

		finally {
			close();
		}
	}

	public void deleteUser() {
		try {

			open();

			db.delete(DatabaseHelper.TABLE_MYPROFILE, DatabaseHelper.KEY_IS_NEW
					+ " = ?", new String[] { "1" });
		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
		}

		finally {
			close();
		}
	}

	public ArrayList<UserDetails> getPushProfile() {
		ArrayList<UserDetails> userList = new ArrayList<UserDetails>();
		open();
		String query;

		query = "select * from " + DatabaseHelper.TABLE_MYPROFILE + " where "
				+ DatabaseHelper.KEY_IS_NEW + "='" + "1" + "'";
		Cursor cursor = db.rawQuery(query, null);
		try {
			if (cursor != null) {
				if (cursor.getCount() > 0) {
					cursor.moveToFirst();
					do {
						UserDetails user = new UserDetails();

						user.setPhone_number(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHONE)));

						user.setPharmacy_name(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHARMA_NAME)));

						user.setAddress(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_ADDRESS)));

						user.setOwner_name(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_OWNER)));

						user.setEmail_id(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_EMAIL)));
						user.setWebsite(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_WEBSITE)));
						user.setOpening_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_OPEN_TIME)));
						user.setClosing_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_CLOSE_TIME)));
						user.setDelivery_time(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_DELIVER_TIME)));
						user.setMin_purchase(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_MIN_PURCHASE)));
						user.setHome_delivery(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_IS_NEW)));
						user.setDatetime(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_DATE)));
						user.setLatitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_LAT)));
						user.setLongitude(cursor.getDouble(cursor
								.getColumnIndex(DatabaseHelper.KEY_LONG)));
						user.setIsDelivery(cursor.getString(cursor
								.getColumnIndex(DatabaseHelper.KEY_IS_DELIVERY)));
						user.setRowid(cursor.getInt(cursor
								.getColumnIndex(DatabaseHelper.KEY_ROW_ID)));

						Image image = new Image();
						image.setImage1(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO1)));

						image.setImage2(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO2)));
						image.setImage3(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO3)));

						image.setImage4(cursor.getBlob(cursor
								.getColumnIndex(DatabaseHelper.KEY_PHOTO4)));
						user.setImage(image);
						System.out.println("Image1:::" + image.getImage1()
								+ "Image2:::" + image.getImage2() + "Image3::"
								+ image.getImage3() + "Image4:::"
								+ image.getImage4());

						userList.add(user);
					} while (cursor.moveToNext());
				}
			}
		} catch (Exception e) {
			Log.e("IPharma", e.getLocalizedMessage());
			e.printStackTrace();
		} finally {
			if (cursor != null)
				cursor.close();
			close();
		}
		return userList;
	}
}
