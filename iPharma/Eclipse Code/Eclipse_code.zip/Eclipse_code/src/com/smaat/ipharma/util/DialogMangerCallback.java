package com.smaat.ipharma.util;

public interface DialogMangerCallback {

	void onItemclick(String SelctedItem, int pos);

	void onOkclick();

}
