package com.smaat.ipharma.entity;

public class AboutUsEntity {

	private String AboutsUsText;

	public String getAboutsUsText() {
		return AboutsUsText;
	}

	public void setAboutsUsText(String aboutsUsText) {
		AboutsUsText = aboutsUsText;
	}
}
