package com.smaat.ipharma.util;

public interface DialogMangerSucessCallback {

	void onOkclick();
}
