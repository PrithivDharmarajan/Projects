package com.smaat.ipharma.entity;

public class Prescription {

}
