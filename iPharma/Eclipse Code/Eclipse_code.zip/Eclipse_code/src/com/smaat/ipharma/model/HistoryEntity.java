package com.smaat.ipharma.model;

public class HistoryEntity {

}
