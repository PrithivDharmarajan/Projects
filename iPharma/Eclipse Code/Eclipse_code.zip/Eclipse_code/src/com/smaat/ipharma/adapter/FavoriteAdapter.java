package com.smaat.ipharma.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.smaat.ipharma.R;

public class FavoriteAdapter extends BaseAdapter {

	private int mLayoutIdentifier;
	private Context mContext;

	public FavoriteAdapter(Context context, int layout) {
		mContext = context;
		mLayoutIdentifier = layout;
	}

	class Holder {

		ImageView pharmacyImage;
		TextView pharmacyName, pharmacyAddress, pharmacyReviews,
				pharmacyDistance, deliveryTime, MinOrder;
		RatingBar mRating;
	}

	public int getCount() {
		return 10;
	}

	public Object getItem(int pos) {
		return pos;
	}

	public long getItemId(int pos) {
		return pos;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		View view = convertView;
		Holder holder = null;
		holder = new Holder();
		LayoutInflater inflater = (LayoutInflater) mContext
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		view = inflater.inflate(mLayoutIdentifier, parent, false);
		holder.pharmacyImage = (ImageView) view
				.findViewById(R.id.pharmacy_image);
		holder.pharmacyName = (TextView) view.findViewById(R.id.pharmacy_name);
		holder.pharmacyAddress = (TextView) view
				.findViewById(R.id.pharmacy_address);
		holder.pharmacyReviews = (TextView) view.findViewById(R.id.reviews);
		holder.deliveryTime = (TextView) view.findViewById(R.id.deliver_time);
		holder.MinOrder = (TextView) view.findViewById(R.id.minorder_rupes);
		holder.pharmacyDistance = (TextView) view.findViewById(R.id.distance);
		holder.pharmacyDistance.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
//				((HomeScreen) mContext).replaceFragment(new ReviewsFragment());
//				HomeScreen.mHeaderText.setText(R.string.reviews);
//				HomeScreen.mHeaderLeft
//						.setBackgroundResource(R.drawable.ic_launcher);
			}
		});

		return view;
	}

}