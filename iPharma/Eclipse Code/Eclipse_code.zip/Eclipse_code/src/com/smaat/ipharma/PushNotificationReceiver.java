package com.smaat.ipharma;

import org.json.JSONObject;

import com.smaat.ipharma.ui.HomeScreen;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.WakefulBroadcastReceiver;

public class PushNotificationReceiver extends WakefulBroadcastReceiver {
	@SuppressWarnings("unused")
	private static final String TAG = "GCMIntentService";

	@SuppressWarnings("unused")
	private JSONObject json;

	@SuppressWarnings("unused")
	private static String message = "", type = "", id = "", alert_msg = "",
			notification_id = "", chat_message = "", group_id = "";

	@SuppressWarnings("unused")
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub

		String message = intent.getExtras().getString("message");
		String type = intent.getExtras().getString("type");
		String purpose = intent.getExtras().getString("purpose");
		if (message != null) {
			generateNotification(context, message);
		}

	}

	@SuppressWarnings("deprecation")
	private static void generateNotification(Context context, String message) {
		int icon = R.drawable.ic_launcher;
		long when = System.currentTimeMillis();
		NotificationManager notificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		Notification notification = new Notification(icon, message, when);

		String title = context.getString(R.string.app_name);

		Intent notificationIntent = new Intent(context, HomeScreen.class);
		// set intent so it does not start a new activity
		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
				| Intent.FLAG_ACTIVITY_SINGLE_TOP);
		PendingIntent intent = PendingIntent.getActivity(context, 0,
				notificationIntent, 0);
		notification.setLatestEventInfo(context, title, message, intent);
		notification.flags |= Notification.FLAG_AUTO_CANCEL;

		// Play default notification sound
		notification.defaults |= Notification.DEFAULT_SOUND;

		// Vibrate if vibrate is enabled
		notification.defaults |= Notification.DEFAULT_VIBRATE;
		notificationManager.notify(0, notification);
	}

}
