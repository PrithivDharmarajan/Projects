package com.smaat.ipharma.entity;
import java.util.ArrayList;


public class PlaceResponse {

	public String error_code;
	public String msg;
	public ArrayList<Places> predictions;

}
