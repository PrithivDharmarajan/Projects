package com.smaat.ipharma.fragment;

import java.util.ArrayList;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import com.androidquery.AQuery;
import com.smaat.ipharma.BaseFragment;
import com.smaat.ipharma.R;
import com.smaat.ipharma.adapter.MapListAdapter.holder;
import com.smaat.ipharma.entity.FavouriteCommonResponse;
import com.smaat.ipharma.entity.MapPropertyEntity;
import com.smaat.ipharma.entity.RateResponseEntity;
import com.smaat.ipharma.entity.WriteReviewEntity;
import com.smaat.ipharma.ui.HomeScreen;
import com.smaat.ipharma.util.AppConstants;
import com.smaat.ipharma.util.DialogManager;
import com.smaat.ipharma.util.DialogMangerCallback;
import com.smaat.ipharma.util.GPSTracker;
import com.smaat.ipharma.util.GlobalMethods;
import com.smaat.ipharma.util.RoundEdgeImageView;
import com.smaat.ipharma.util.TypefaceSingleton;
import com.smaat.ipharma.webservice.APIRequestHandler;
import com.smaat.ipharma.webservice.UserInterfaceAPI;

public class FavoriteFragment extends BaseFragment implements
		DialogMangerCallback {
	private TableLayout mFavTable;
	RoundEdgeImageView pharmacyImage;
	TextView pharmacyName, pharmacyAddress, pharmacyReviews, pharmacyDistance,
			deliveryTime, MinOrder;
	RatingBar mRating;
	LinearLayout mOffersListItemView;
	private Button mFavButton;
	private GPSTracker tracker;
	private AQuery aq1;
	public static String mShopId, mUserID;
	private int mSelectedPos;
	ArrayList<MapPropertyEntity> mMapProperties;
	private float mRate;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootview = inflater.inflate(R.layout.fragment_favourite,
				container, false);
		setupUI(rootview);
		return rootview;
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		ViewGroup mViewGroup = (ViewGroup) view
				.findViewById(R.id.parent_layout);
		Typeface mTypeface = TypefaceSingleton.getInstance().getHelvetica(
				getActivity());
		setFont(mViewGroup, mTypeface);
		setupUI(mViewGroup);

		AppConstants.FRAG = AppConstants.MAP_SCREEN;
		hideSoftKeyboard(getActivity());
		callFavouriteService(); // API Call
		initComponents(view);
		HomeScreen.mHeaderLeftLay.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {

				HomeScreen.onBackMove(getActivity());
			}
		});
	}

	private void callFavouriteService() {

		String mUserID = GlobalMethods.getUserID(getActivity());
		tracker = new GPSTracker(getActivity());
		String mLat = "";
		String mLongit = "";
		if (tracker != null) {
			mLat = tracker.getLatitude() + "";
			mLongit = tracker.getLongitude() + "";
		}
		APIRequestHandler.getInstance().getFavouriteShops(mUserID, mLat,
				mLongit, this);
	}

	@Override
	public void onRequestSuccess(Object responseObj) {

		if (responseObj instanceof WriteReviewEntity) {

			WriteReviewEntity mWriteReviewResponse = (WriteReviewEntity) responseObj;

			if (mWriteReviewResponse.getStatus().equalsIgnoreCase(
					AppConstants.SUCCESS_CODE)) {
				callFavouriteService();
			} else {
				DialogManager.showCustomAlertDialog(getActivity(),
						FavoriteFragment.this, mWriteReviewResponse.getMsg());
			}

		}

		if (responseObj instanceof FavouriteCommonResponse) {

			FavouriteCommonResponse mFavouriteShopsResponse = (FavouriteCommonResponse) responseObj;

			if (mFavouriteShopsResponse.getStatus().equalsIgnoreCase(
					AppConstants.SUCCESS_CODE)) {

				if (mFavouriteShopsResponse.getResult() != null
						&& mFavouriteShopsResponse.getResult().size() != 0) {
					mMapProperties = mFavouriteShopsResponse.getResult();
					setAdapter(mFavouriteShopsResponse.getResult());
				} else {
					mFavTable.removeAllViews();
					DialogManager.showCustomAlertDialog(getActivity(),
							FavoriteFragment.this,
							getString(R.string.no_favourite_shop));
				}
			} else {
				DialogManager
						.showCustomAlertDialog(getActivity(),
								FavoriteFragment.this,
								mFavouriteShopsResponse.getMsg());
			}

		}
		if (responseObj instanceof RateResponseEntity) {
			RateResponseEntity mRatingResponse = (RateResponseEntity) responseObj;
			if (mRatingResponse.getStatus().equalsIgnoreCase(
					AppConstants.SUCCESS_CODE)
					|| mRatingResponse.getStatus().equalsIgnoreCase("success")) {
				DialogManager.showCustomAlertDialog(getActivity(),
						FavoriteFragment.this, getString(R.string.rating_added));
				mMapProperties.get(mSelectedPos).setAvgRating(
						String.valueOf(mRatingResponse.getResult()));
				setAdapter(mMapProperties);

			} else {

				DialogManager.showCustomAlertDialog(getActivity(), this,
						mRatingResponse.getMsg());
			}
		}
		super.onRequestSuccess(responseObj);
	}

	@Override
	public void onRequestFailure(RetrofitError errorCode) {

		super.onRequestFailure(errorCode);
	}

	private void initComponents(View view) {

		mFavTable = (TableLayout) view.findViewById(R.id.favourite_table);

	}

	public void setAdapter(final ArrayList<MapPropertyEntity> fav_list) {
		mFavTable.removeAllViews();
		if (fav_list != null) {
			for (int i = 0; i < fav_list.size(); i++) {
				LayoutInflater inflater = (LayoutInflater) getActivity()
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

				View view = inflater.inflate(R.layout.favorite_item, null);

				pharmacyImage = (RoundEdgeImageView) view
						.findViewById(R.id.pharmacy_image_mask);
				aq1 = new AQuery(getActivity()).recycle(view);

				aq1.id(pharmacyImage)
						.progress(R.id.progress)
						.image("http://smaatapps.com/iPharma/admin/"
								+ fav_list.get(i).getShopIcon(), true, true, 0,
								R.drawable.ipharma_message_icon, null, 0, 1.0f);
				pharmacyName = (TextView) view.findViewById(R.id.pharmacy_name);
				pharmacyName.setTypeface(HomeScreen.mHelveticaNormal);
				pharmacyAddress = (TextView) view
						.findViewById(R.id.pharmacy_address);
				pharmacyAddress.setTypeface(HomeScreen.mHelveticaNormal);
				pharmacyReviews = (TextView) view.findViewById(R.id.reviews);
				pharmacyReviews.setTypeface(HomeScreen.mHelveticaNormal);
				deliveryTime = (TextView) view.findViewById(R.id.deliver_time);
				deliveryTime.setTypeface(HomeScreen.mHelveticaNormal);
				MinOrder = (TextView) view.findViewById(R.id.minorder_rupes);
				MinOrder.setTypeface(HomeScreen.mHelveticaNormal);
				pharmacyDistance = (TextView) view.findViewById(R.id.distance);
				pharmacyDistance.setTypeface(HomeScreen.mHelveticaNormal);
				mFavButton = (Button) view.findViewById(R.id.fav_button);
				mOffersListItemView = (LinearLayout) view
						.findViewById(R.id.offers_list_item_view);

				mOffersListItemView.setTag(i);
				mFavButton.setTag(i);

				RelativeLayout mFav_lay = (RelativeLayout) view
						.findViewById(R.id.fav_lay);
				mFav_lay.setTag(i);

				mRating = (RatingBar) view.findViewById(R.id.fav_ratingbar);
				mRating.setRating(Float.valueOf(fav_list.get(i).getAvgRating()));

				mOffersListItemView.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						int pos = Integer.parseInt(String.valueOf(v.getTag()));
						HomeScreen.mFragment = new OrderNowFragment();
						Bundle bundle = new Bundle();
						bundle.putSerializable("pharmcay_details",
								fav_list.get(pos));
						AppConstants.FROM_MAPFAVORITE_SCREEN = AppConstants.FAVORITE_SCREEN;
						((HomeScreen) getActivity()).mFragment
								.setArguments(bundle);
						((HomeScreen) getActivity()).replaceFragment(
								((HomeScreen) getActivity()).mFragment, true);
						HomeScreen.mHeaderRightLay
								.setVisibility(View.INVISIBLE);
						HomeScreen.mHeaderLeft
								.setBackgroundResource(R.drawable.back_butto);

					}
				});

				mFav_lay.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						int pos = Integer.parseInt(String.valueOf(v.getTag()));
						mSelectedPos = pos;
						mShopId = fav_list.get(pos).getPharmacyID();
						showRateDialog();
					}
				});

				pharmacyName.setText(fav_list.get(i).getShopName());
				pharmacyAddress.setText(fav_list.get(i).getAddress());
				pharmacyReviews.setText(fav_list.get(i).getTotalReviews());
				deliveryTime.setText(fav_list.get(i).getDeliveryTime());
				// pharmacyDistance.setText(fav_list.get(i).get)

				mFavButton.setOnClickListener(new OnClickListener() {

					public void onClick(View v) {
						int pos = Integer.parseInt(String.valueOf(v.getTag()));
						String shop_id = fav_list.get(pos).getPharmacyID();
						callUnFavouriteservice(shop_id);
					}
				});

				mFavTable.addView(view);

			}
		}
	}

	private void showRateDialog() {

		mDialog = new Dialog(getActivity());
		mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mDialog.setContentView(R.layout.dialog_rate);

		mDialog.getWindow().setBackgroundDrawable(
				new ColorDrawable(Color.TRANSPARENT));
		WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
		wmlp.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;

		mDialog.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
						| WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		Button rate = (Button) mDialog.findViewById(R.id.rate_it);
		Button cancel = (Button) mDialog.findViewById(R.id.cancel);
		rate.setTypeface(HomeScreen.mHelveticaBold);
		cancel.setTypeface(HomeScreen.mHelveticaBold);
		TextView mRateText = (TextView) mDialog.findViewById(R.id.rate_text);
		final TextView mRating_avg_txt = (TextView) mDialog
				.findViewById(R.id.rating_avg_txt);
		mRating_avg_txt.setTypeface(HomeScreen.mHelveticaBold);
		mRateText.setTypeface(HomeScreen.mHelveticaNormal);
		final RatingBar mFav_ratingbar = (RatingBar) mDialog
				.findViewById(R.id.fav_ratingbar);
		final Button mRating_icons = (Button) mDialog
				.findViewById(R.id.rating_icons);

		mFav_ratingbar
				.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {

					public void onRatingChanged(RatingBar ratingBar,
							float rating, boolean fromUser) {
						switch ((int) mFav_ratingbar.getRating()) {
						case 1:
							mRating_avg_txt.setText(getActivity().getString(
									R.string.poor));
							mRating_icons
									.setBackgroundResource(R.drawable.poor);
							break;
						case 2:
							mRating_avg_txt.setText(getActivity().getString(
									R.string.bad));
							mRating_icons.setBackgroundResource(R.drawable.bad);
							break;
						case 3:
							mRating_avg_txt.setText(getActivity().getString(
									R.string.average));
							mRating_icons
									.setBackgroundResource(R.drawable.average);
							break;
						case 4:
							mRating_avg_txt.setText(getActivity().getString(
									R.string.good));
							mRating_icons
									.setBackgroundResource(R.drawable.good);
							break;
						case 5:
							mRating_avg_txt.setText(getActivity().getString(
									R.string.excellent));
							mRating_icons
									.setBackgroundResource(R.drawable.excellent);
							break;
						}
					}
				});
		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mDialog.dismiss();
			}
		});
		rate.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				float rating_value = mFav_ratingbar.getRating();
				mRate = rating_value;
				callPharmacyRatingService(rating_value);
				mDialog.dismiss();
			}
		});

		mDialog.show();
	}

	private void callPharmacyRatingService(float rating_value) {
		String rating = String.valueOf(rating_value);
		APIRequestHandler.getInstance().shopRating(mShopId,
				GlobalMethods.getUserID(getActivity()), rating, this);
		// DialogManager.showProgress(getActivity());
		// RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(
		// AppConstants.Base_Url).build();
		// UserInterfaceAPI interfaces = restAdapter
		// .create(UserInterfaceAPI.class);
		//
		// String rating = String.valueOf(rating_value);
		//
		// // String UserID = GlobalMethods.getUserID(context);
		// interfaces.shopRating(mShopId, mUserID, rating,
		// new Callback<RateResponseEntity>() {
		//
		// public void failure(RetrofitError arg0) {
		//
		// DialogManager.hideProgress(getActivity());
		// DialogManager.showCustomAlertDialog(getActivity(),
		// FavoriteFragment.this,
		// getActivity().getString(R.string.no_network));
		// }
		//
		// public void success(RateResponseEntity response,
		// Response obj) {
		//
		// if (!response.getStatus().equalsIgnoreCase(
		// AppConstants.FAILURE_CODE)) {
		//
		// DialogManager.hideProgress(getActivity());
		// // DialogManager.showCustomAlertDialog(getActivity(),
		// // FavoriteFragment.this,
		// // "Rating Added Sucessfully.");
		// // notifyDataSetChanged();
		// // mholder.review_rating.setRating(Float
		// // .valueOf(response.getResult()));
		// }
		// }
		//
		// });
	}

	private void callUnFavouriteservice(String mShopId) {
		String UserID = GlobalMethods.getUserID(getActivity());
		APIRequestHandler.getInstance()
				.addFavourite(mShopId, UserID, "2", this);

	}

	// @Override
	// public void onDestroy() {
	// super.onDestroy();
	// getActivity().getSupportFragmentManager().beginTransaction()
	// .remove(this).commit();
	// }

	public void onItemclick(String SelctedItem, int pos) {
		// TODO Auto-generated method stub

	}

	public void onOkclick() {
		// TODO Auto-generated method stub

	}
}
